﻿namespace UzielLopez_A1_VS_1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pict_UMI = new System.Windows.Forms.PictureBox();
            this.lab_Titulo = new System.Windows.Forms.Label();
            this.lab_Datos_Estudiante = new System.Windows.Forms.Label();
            this.lab_Nombre_Estudiante = new System.Windows.Forms.Label();
            this.lab_Fecha_Nacimiento = new System.Windows.Forms.Label();
            this.lab_Direccion = new System.Windows.Forms.Label();
            this.lab_Estado = new System.Windows.Forms.Label();
            this.txt_Nombre = new System.Windows.Forms.TextBox();
            this.txt_Fecha_Nacimiento = new System.Windows.Forms.TextBox();
            this.txt_Dirección = new System.Windows.Forms.TextBox();
            this.list_Estado = new System.Windows.Forms.ListBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lab_Horarios = new System.Windows.Forms.Label();
            this.rd_btn_Matutino = new System.Windows.Forms.RadioButton();
            this.rd_btn_Vespertino = new System.Windows.Forms.RadioButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.btn_Cerrar = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pict_UMI)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lab_Titulo);
            this.panel1.Controls.Add(this.pict_UMI);
            this.panel1.Location = new System.Drawing.Point(0, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(801, 100);
            this.panel1.TabIndex = 0;
            // 
            // pict_UMI
            // 
            this.pict_UMI.Image = ((System.Drawing.Image)(resources.GetObject("pict_UMI.Image")));
            this.pict_UMI.Location = new System.Drawing.Point(-1, -1);
            this.pict_UMI.Name = "pict_UMI";
            this.pict_UMI.Size = new System.Drawing.Size(101, 102);
            this.pict_UMI.TabIndex = 0;
            this.pict_UMI.TabStop = false;
            // 
            // lab_Titulo
            // 
            this.lab_Titulo.AutoSize = true;
            this.lab_Titulo.Font = new System.Drawing.Font("Microsoft Tai Le", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Titulo.Location = new System.Drawing.Point(209, 33);
            this.lab_Titulo.Name = "lab_Titulo";
            this.lab_Titulo.Size = new System.Drawing.Size(395, 45);
            this.lab_Titulo.TabIndex = 1;
            this.lab_Titulo.Text = "Expediente de Alumno";
            // 
            // lab_Datos_Estudiante
            // 
            this.lab_Datos_Estudiante.AutoSize = true;
            this.lab_Datos_Estudiante.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Datos_Estudiante.Location = new System.Drawing.Point(47, 118);
            this.lab_Datos_Estudiante.Name = "lab_Datos_Estudiante";
            this.lab_Datos_Estudiante.Size = new System.Drawing.Size(114, 14);
            this.lab_Datos_Estudiante.TabIndex = 1;
            this.lab_Datos_Estudiante.Text = "Datos del Estudiante";
            // 
            // lab_Nombre_Estudiante
            // 
            this.lab_Nombre_Estudiante.AutoSize = true;
            this.lab_Nombre_Estudiante.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Nombre_Estudiante.Location = new System.Drawing.Point(47, 152);
            this.lab_Nombre_Estudiante.Name = "lab_Nombre_Estudiante";
            this.lab_Nombre_Estudiante.Size = new System.Drawing.Size(121, 17);
            this.lab_Nombre_Estudiante.TabIndex = 2;
            this.lab_Nombre_Estudiante.Text = "Nombre Completo:";
            // 
            // lab_Fecha_Nacimiento
            // 
            this.lab_Fecha_Nacimiento.AutoSize = true;
            this.lab_Fecha_Nacimiento.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Fecha_Nacimiento.Location = new System.Drawing.Point(47, 205);
            this.lab_Fecha_Nacimiento.Name = "lab_Fecha_Nacimiento";
            this.lab_Fecha_Nacimiento.Size = new System.Drawing.Size(133, 17);
            this.lab_Fecha_Nacimiento.TabIndex = 3;
            this.lab_Fecha_Nacimiento.Text = "Fecha de Nacimiento:";
            // 
            // lab_Direccion
            // 
            this.lab_Direccion.AutoSize = true;
            this.lab_Direccion.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Direccion.Location = new System.Drawing.Point(47, 258);
            this.lab_Direccion.Name = "lab_Direccion";
            this.lab_Direccion.Size = new System.Drawing.Size(65, 17);
            this.lab_Direccion.TabIndex = 4;
            this.lab_Direccion.Text = "Dirección:";
            // 
            // lab_Estado
            // 
            this.lab_Estado.AutoSize = true;
            this.lab_Estado.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Estado.Location = new System.Drawing.Point(47, 311);
            this.lab_Estado.Name = "lab_Estado";
            this.lab_Estado.Size = new System.Drawing.Size(51, 17);
            this.lab_Estado.TabIndex = 5;
            this.lab_Estado.Text = "Estado:";
            // 
            // txt_Nombre
            // 
            this.txt_Nombre.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nombre.Location = new System.Drawing.Point(189, 151);
            this.txt_Nombre.Name = "txt_Nombre";
            this.txt_Nombre.Size = new System.Drawing.Size(316, 23);
            this.txt_Nombre.TabIndex = 6;
            // 
            // txt_Fecha_Nacimiento
            // 
            this.txt_Fecha_Nacimiento.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Fecha_Nacimiento.Location = new System.Drawing.Point(189, 203);
            this.txt_Fecha_Nacimiento.Name = "txt_Fecha_Nacimiento";
            this.txt_Fecha_Nacimiento.Size = new System.Drawing.Size(316, 23);
            this.txt_Fecha_Nacimiento.TabIndex = 7;
            // 
            // txt_Dirección
            // 
            this.txt_Dirección.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Dirección.Location = new System.Drawing.Point(189, 256);
            this.txt_Dirección.Name = "txt_Dirección";
            this.txt_Dirección.Size = new System.Drawing.Size(316, 23);
            this.txt_Dirección.TabIndex = 8;
            // 
            // list_Estado
            // 
            this.list_Estado.FormattingEnabled = true;
            this.list_Estado.Items.AddRange(new object[] {
            "Aguascalientes",
            "Baja California",
            "Baja California Sur",
            "Campeche",
            "Chiapas",
            "Chihuahua",
            "Ciudad de México",
            "Coahuila",
            "Colima",
            "Durango",
            "Estado de México",
            "Guanajuato",
            "Guerrero",
            "Hidalgo",
            "Jalisco",
            "Michoacán",
            "Morelos",
            "Nayarit",
            "Nuevo León",
            "Oaxaca",
            "Puebla",
            "Querétaro",
            "Quintana Roo",
            "San Luis Potosí",
            "Sinaloa",
            "Sonora",
            "Tabasco",
            "Tamaulipas",
            "Tlaxcala",
            "Veracruz",
            "Yucatán",
            "Zacatecas"});
            this.list_Estado.Location = new System.Drawing.Point(189, 311);
            this.list_Estado.Name = "list_Estado";
            this.list_Estado.Size = new System.Drawing.Size(316, 56);
            this.list_Estado.TabIndex = 9;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(37, 125);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(491, 262);
            this.panel2.TabIndex = 10;
            // 
            // lab_Horarios
            // 
            this.lab_Horarios.AutoSize = true;
            this.lab_Horarios.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Horarios.Location = new System.Drawing.Point(568, 118);
            this.lab_Horarios.Name = "lab_Horarios";
            this.lab_Horarios.Size = new System.Drawing.Size(51, 14);
            this.lab_Horarios.TabIndex = 11;
            this.lab_Horarios.Text = "Horarios";
            // 
            // rd_btn_Matutino
            // 
            this.rd_btn_Matutino.AutoSize = true;
            this.rd_btn_Matutino.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_btn_Matutino.Location = new System.Drawing.Point(571, 152);
            this.rd_btn_Matutino.Name = "rd_btn_Matutino";
            this.rd_btn_Matutino.Size = new System.Drawing.Size(74, 20);
            this.rd_btn_Matutino.TabIndex = 12;
            this.rd_btn_Matutino.TabStop = true;
            this.rd_btn_Matutino.Text = "Matutino";
            this.rd_btn_Matutino.UseVisualStyleBackColor = true;
            // 
            // rd_btn_Vespertino
            // 
            this.rd_btn_Vespertino.AutoSize = true;
            this.rd_btn_Vespertino.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rd_btn_Vespertino.Location = new System.Drawing.Point(571, 204);
            this.rd_btn_Vespertino.Name = "rd_btn_Vespertino";
            this.rd_btn_Vespertino.Size = new System.Drawing.Size(81, 20);
            this.rd_btn_Vespertino.TabIndex = 13;
            this.rd_btn_Vespertino.TabStop = true;
            this.rd_btn_Vespertino.Text = "Vespertino";
            this.rd_btn_Vespertino.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Location = new System.Drawing.Point(550, 125);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(215, 262);
            this.panel3.TabIndex = 11;
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Guardar.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Location = new System.Drawing.Point(550, 405);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(95, 23);
            this.btn_Guardar.TabIndex = 14;
            this.btn_Guardar.Text = "Guardar";
            this.btn_Guardar.UseVisualStyleBackColor = false;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // btn_Cerrar
            // 
            this.btn_Cerrar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Cerrar.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cerrar.Location = new System.Drawing.Point(670, 405);
            this.btn_Cerrar.Name = "btn_Cerrar";
            this.btn_Cerrar.Size = new System.Drawing.Size(95, 23);
            this.btn_Cerrar.TabIndex = 15;
            this.btn_Cerrar.Text = "Cerrar";
            this.btn_Cerrar.UseVisualStyleBackColor = false;
            this.btn_Cerrar.Click += new System.EventHandler(this.btn_Cerrar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_Cerrar);
            this.Controls.Add(this.btn_Guardar);
            this.Controls.Add(this.rd_btn_Vespertino);
            this.Controls.Add(this.rd_btn_Matutino);
            this.Controls.Add(this.lab_Horarios);
            this.Controls.Add(this.list_Estado);
            this.Controls.Add(this.txt_Dirección);
            this.Controls.Add(this.txt_Fecha_Nacimiento);
            this.Controls.Add(this.txt_Nombre);
            this.Controls.Add(this.lab_Estado);
            this.Controls.Add(this.lab_Direccion);
            this.Controls.Add(this.lab_Fecha_Nacimiento);
            this.Controls.Add(this.lab_Nombre_Estudiante);
            this.Controls.Add(this.lab_Datos_Estudiante);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pict_UMI)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pict_UMI;
        private System.Windows.Forms.Label lab_Titulo;
        private System.Windows.Forms.Label lab_Datos_Estudiante;
        private System.Windows.Forms.Label lab_Nombre_Estudiante;
        private System.Windows.Forms.Label lab_Fecha_Nacimiento;
        private System.Windows.Forms.Label lab_Direccion;
        private System.Windows.Forms.Label lab_Estado;
        private System.Windows.Forms.TextBox txt_Nombre;
        private System.Windows.Forms.TextBox txt_Fecha_Nacimiento;
        private System.Windows.Forms.TextBox txt_Dirección;
        private System.Windows.Forms.ListBox list_Estado;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lab_Horarios;
        private System.Windows.Forms.RadioButton rd_btn_Matutino;
        private System.Windows.Forms.RadioButton rd_btn_Vespertino;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.Button btn_Cerrar;
    }
}

