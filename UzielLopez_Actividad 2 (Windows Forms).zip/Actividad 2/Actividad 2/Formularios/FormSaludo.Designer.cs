﻿namespace Actividad_2.Formularios
{
    partial class FormSaludo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSaludo));
            this.panel_Saludo = new System.Windows.Forms.Panel();
            this.lbl_Saludo = new System.Windows.Forms.Label();
            this.picbox_UMI = new System.Windows.Forms.PictureBox();
            this.lbl_Intrrucciones_Saludo = new System.Windows.Forms.Label();
            this.lbl_NombreSaludo = new System.Windows.Forms.Label();
            this.picbox_Saludo = new System.Windows.Forms.PictureBox();
            this.txt_Nombre_Saludo = new System.Windows.Forms.TextBox();
            this.btn_Saludar = new System.Windows.Forms.Button();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.panel_Saludo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_UMI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_Saludo)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Saludo
            // 
            this.panel_Saludo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel_Saludo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Saludo.Controls.Add(this.lbl_Saludo);
            this.panel_Saludo.Controls.Add(this.picbox_UMI);
            this.panel_Saludo.Location = new System.Drawing.Point(0, 0);
            this.panel_Saludo.Name = "panel_Saludo";
            this.panel_Saludo.Size = new System.Drawing.Size(748, 100);
            this.panel_Saludo.TabIndex = 1;
            // 
            // lbl_Saludo
            // 
            this.lbl_Saludo.AutoSize = true;
            this.lbl_Saludo.Font = new System.Drawing.Font("Microsoft Tai Le", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Saludo.Location = new System.Drawing.Point(298, 23);
            this.lbl_Saludo.Name = "lbl_Saludo";
            this.lbl_Saludo.Size = new System.Drawing.Size(140, 48);
            this.lbl_Saludo.TabIndex = 1;
            this.lbl_Saludo.Text = "Saludo";
            this.lbl_Saludo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picbox_UMI
            // 
            this.picbox_UMI.Image = ((System.Drawing.Image)(resources.GetObject("picbox_UMI.Image")));
            this.picbox_UMI.Location = new System.Drawing.Point(-1, -1);
            this.picbox_UMI.Name = "picbox_UMI";
            this.picbox_UMI.Size = new System.Drawing.Size(100, 102);
            this.picbox_UMI.TabIndex = 0;
            this.picbox_UMI.TabStop = false;
            // 
            // lbl_Intrrucciones_Saludo
            // 
            this.lbl_Intrrucciones_Saludo.AutoSize = true;
            this.lbl_Intrrucciones_Saludo.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Intrrucciones_Saludo.Location = new System.Drawing.Point(202, 116);
            this.lbl_Intrrucciones_Saludo.Name = "lbl_Intrrucciones_Saludo";
            this.lbl_Intrrucciones_Saludo.Size = new System.Drawing.Size(350, 21);
            this.lbl_Intrrucciones_Saludo.TabIndex = 2;
            this.lbl_Intrrucciones_Saludo.Text = "Coloca tu nombre y recibe un amable saludo";
            // 
            // lbl_NombreSaludo
            // 
            this.lbl_NombreSaludo.AutoSize = true;
            this.lbl_NombreSaludo.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NombreSaludo.Location = new System.Drawing.Point(187, 240);
            this.lbl_NombreSaludo.Name = "lbl_NombreSaludo";
            this.lbl_NombreSaludo.Size = new System.Drawing.Size(67, 19);
            this.lbl_NombreSaludo.TabIndex = 3;
            this.lbl_NombreSaludo.Text = "Nombre:";
            // 
            // picbox_Saludo
            // 
            this.picbox_Saludo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picbox_Saludo.Image = ((System.Drawing.Image)(resources.GetObject("picbox_Saludo.Image")));
            this.picbox_Saludo.Location = new System.Drawing.Point(327, 150);
            this.picbox_Saludo.Name = "picbox_Saludo";
            this.picbox_Saludo.Size = new System.Drawing.Size(80, 76);
            this.picbox_Saludo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picbox_Saludo.TabIndex = 4;
            this.picbox_Saludo.TabStop = false;
            // 
            // txt_Nombre_Saludo
            // 
            this.txt_Nombre_Saludo.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nombre_Saludo.Location = new System.Drawing.Point(266, 237);
            this.txt_Nombre_Saludo.Name = "txt_Nombre_Saludo";
            this.txt_Nombre_Saludo.Size = new System.Drawing.Size(293, 27);
            this.txt_Nombre_Saludo.TabIndex = 5;
            this.txt_Nombre_Saludo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Saludar
            // 
            this.btn_Saludar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Saludar.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Saludar.Location = new System.Drawing.Point(524, 310);
            this.btn_Saludar.Name = "btn_Saludar";
            this.btn_Saludar.Size = new System.Drawing.Size(142, 34);
            this.btn_Saludar.TabIndex = 6;
            this.btn_Saludar.Text = "Saludar";
            this.btn_Saludar.UseVisualStyleBackColor = false;
            this.btn_Saludar.Click += new System.EventHandler(this.btn_Saludar_Click);
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Regresar.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Location = new System.Drawing.Point(75, 310);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(142, 34);
            this.btn_Regresar.TabIndex = 7;
            this.btn_Regresar.Text = "Regresar";
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // FormSaludo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(750, 400);
            this.Controls.Add(this.btn_Regresar);
            this.Controls.Add(this.btn_Saludar);
            this.Controls.Add(this.txt_Nombre_Saludo);
            this.Controls.Add(this.picbox_Saludo);
            this.Controls.Add(this.lbl_NombreSaludo);
            this.Controls.Add(this.lbl_Intrrucciones_Saludo);
            this.Controls.Add(this.panel_Saludo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormSaludo";
            this.Text = "FormSaludo";
            this.panel_Saludo.ResumeLayout(false);
            this.panel_Saludo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_UMI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_Saludo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_Saludo;
        private System.Windows.Forms.Label lbl_Saludo;
        private System.Windows.Forms.PictureBox picbox_UMI;
        private System.Windows.Forms.Label lbl_Intrrucciones_Saludo;
        private System.Windows.Forms.Label lbl_NombreSaludo;
        private System.Windows.Forms.PictureBox picbox_Saludo;
        private System.Windows.Forms.TextBox txt_Nombre_Saludo;
        private System.Windows.Forms.Button btn_Saludar;
        private System.Windows.Forms.Button btn_Regresar;
    }
}