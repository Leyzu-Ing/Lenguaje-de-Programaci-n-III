﻿namespace Actividad_2.Formularios
{
    partial class Form_Operaciones_Basicas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Operaciones_Basicas));
            this.panel_Menu = new System.Windows.Forms.Panel();
            this.lbl_Operaciones_Basicas = new System.Windows.Forms.Label();
            this.picbox_UMI = new System.Windows.Forms.PictureBox();
            this.lbl_instrucciones_Op_Bas = new System.Windows.Forms.Label();
            this.lbl_Numero1 = new System.Windows.Forms.Label();
            this.lab_Numero2 = new System.Windows.Forms.Label();
            this.txt_Numero1 = new System.Windows.Forms.TextBox();
            this.text_Numero2 = new System.Windows.Forms.TextBox();
            this.btn_suma = new System.Windows.Forms.Button();
            this.btn_resta = new System.Windows.Forms.Button();
            this.btn_multiplicacion = new System.Windows.Forms.Button();
            this.btn_Division = new System.Windows.Forms.Button();
            this.lab_Resultado = new System.Windows.Forms.Label();
            this.txt_Resultado = new System.Windows.Forms.TextBox();
            this.btn_limpiar = new System.Windows.Forms.Button();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel_Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_UMI)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Menu
            // 
            this.panel_Menu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel_Menu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Menu.Controls.Add(this.lbl_Operaciones_Basicas);
            this.panel_Menu.Controls.Add(this.picbox_UMI);
            this.panel_Menu.Location = new System.Drawing.Point(0, 0);
            this.panel_Menu.Name = "panel_Menu";
            this.panel_Menu.Size = new System.Drawing.Size(748, 100);
            this.panel_Menu.TabIndex = 1;
            // 
            // lbl_Operaciones_Basicas
            // 
            this.lbl_Operaciones_Basicas.AutoSize = true;
            this.lbl_Operaciones_Basicas.Font = new System.Drawing.Font("Microsoft Tai Le", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Operaciones_Basicas.Location = new System.Drawing.Point(184, 23);
            this.lbl_Operaciones_Basicas.Name = "lbl_Operaciones_Basicas";
            this.lbl_Operaciones_Basicas.Size = new System.Drawing.Size(371, 48);
            this.lbl_Operaciones_Basicas.TabIndex = 1;
            this.lbl_Operaciones_Basicas.Text = "Operaciones Básicas";
            this.lbl_Operaciones_Basicas.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picbox_UMI
            // 
            this.picbox_UMI.Image = ((System.Drawing.Image)(resources.GetObject("picbox_UMI.Image")));
            this.picbox_UMI.Location = new System.Drawing.Point(-1, -1);
            this.picbox_UMI.Name = "picbox_UMI";
            this.picbox_UMI.Size = new System.Drawing.Size(100, 102);
            this.picbox_UMI.TabIndex = 0;
            this.picbox_UMI.TabStop = false;
            // 
            // lbl_instrucciones_Op_Bas
            // 
            this.lbl_instrucciones_Op_Bas.AutoSize = true;
            this.lbl_instrucciones_Op_Bas.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_instrucciones_Op_Bas.Location = new System.Drawing.Point(127, 133);
            this.lbl_instrucciones_Op_Bas.Name = "lbl_instrucciones_Op_Bas";
            this.lbl_instrucciones_Op_Bas.Size = new System.Drawing.Size(486, 19);
            this.lbl_instrucciones_Op_Bas.TabIndex = 5;
            this.lbl_instrucciones_Op_Bas.Text = "Coloca los numeros que te agraden para realizar operaciones basicas";
            // 
            // lbl_Numero1
            // 
            this.lbl_Numero1.AutoSize = true;
            this.lbl_Numero1.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Numero1.Location = new System.Drawing.Point(273, 178);
            this.lbl_Numero1.Name = "lbl_Numero1";
            this.lbl_Numero1.Size = new System.Drawing.Size(69, 16);
            this.lbl_Numero1.TabIndex = 6;
            this.lbl_Numero1.Text = "Numero 1:";
            // 
            // lab_Numero2
            // 
            this.lab_Numero2.AutoSize = true;
            this.lab_Numero2.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Numero2.Location = new System.Drawing.Point(273, 211);
            this.lab_Numero2.Name = "lab_Numero2";
            this.lab_Numero2.Size = new System.Drawing.Size(69, 16);
            this.lab_Numero2.TabIndex = 7;
            this.lab_Numero2.Text = "Numero 2:";
            // 
            // txt_Numero1
            // 
            this.txt_Numero1.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Numero1.Location = new System.Drawing.Point(362, 175);
            this.txt_Numero1.Name = "txt_Numero1";
            this.txt_Numero1.Size = new System.Drawing.Size(125, 23);
            this.txt_Numero1.TabIndex = 9;
            this.txt_Numero1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // text_Numero2
            // 
            this.text_Numero2.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Numero2.Location = new System.Drawing.Point(362, 208);
            this.text_Numero2.Name = "text_Numero2";
            this.text_Numero2.Size = new System.Drawing.Size(125, 23);
            this.text_Numero2.TabIndex = 10;
            this.text_Numero2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_suma
            // 
            this.btn_suma.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_suma.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_suma.Location = new System.Drawing.Point(133, 251);
            this.btn_suma.Name = "btn_suma";
            this.btn_suma.Size = new System.Drawing.Size(81, 27);
            this.btn_suma.TabIndex = 11;
            this.btn_suma.Text = "Suma";
            this.btn_suma.UseVisualStyleBackColor = false;
            this.btn_suma.Click += new System.EventHandler(this.btn_suma_Click);
            // 
            // btn_resta
            // 
            this.btn_resta.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_resta.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_resta.Location = new System.Drawing.Point(257, 251);
            this.btn_resta.Name = "btn_resta";
            this.btn_resta.Size = new System.Drawing.Size(81, 27);
            this.btn_resta.TabIndex = 12;
            this.btn_resta.Text = "Resta";
            this.btn_resta.UseVisualStyleBackColor = false;
            this.btn_resta.Click += new System.EventHandler(this.btn_resta_Click);
            // 
            // btn_multiplicacion
            // 
            this.btn_multiplicacion.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_multiplicacion.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_multiplicacion.Location = new System.Drawing.Point(381, 251);
            this.btn_multiplicacion.Name = "btn_multiplicacion";
            this.btn_multiplicacion.Size = new System.Drawing.Size(106, 27);
            this.btn_multiplicacion.TabIndex = 13;
            this.btn_multiplicacion.Text = "Multiplicación";
            this.btn_multiplicacion.UseVisualStyleBackColor = false;
            this.btn_multiplicacion.Click += new System.EventHandler(this.btn_multiplicacion_Click);
            // 
            // btn_Division
            // 
            this.btn_Division.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btn_Division.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Division.Location = new System.Drawing.Point(530, 251);
            this.btn_Division.Name = "btn_Division";
            this.btn_Division.Size = new System.Drawing.Size(81, 27);
            this.btn_Division.TabIndex = 14;
            this.btn_Division.Text = "División";
            this.btn_Division.UseVisualStyleBackColor = false;
            this.btn_Division.Click += new System.EventHandler(this.btn_Division_Click);
            // 
            // lab_Resultado
            // 
            this.lab_Resultado.AutoSize = true;
            this.lab_Resultado.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Resultado.Location = new System.Drawing.Point(273, 296);
            this.lab_Resultado.Name = "lab_Resultado";
            this.lab_Resultado.Size = new System.Drawing.Size(65, 16);
            this.lab_Resultado.TabIndex = 15;
            this.lab_Resultado.Text = "Resultado";
            // 
            // txt_Resultado
            // 
            this.txt_Resultado.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Resultado.Location = new System.Drawing.Point(362, 289);
            this.txt_Resultado.Name = "txt_Resultado";
            this.txt_Resultado.Size = new System.Drawing.Size(125, 23);
            this.txt_Resultado.TabIndex = 16;
            this.txt_Resultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_limpiar
            // 
            this.btn_limpiar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_limpiar.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_limpiar.Location = new System.Drawing.Point(490, 351);
            this.btn_limpiar.Name = "btn_limpiar";
            this.btn_limpiar.Size = new System.Drawing.Size(123, 28);
            this.btn_limpiar.TabIndex = 26;
            this.btn_limpiar.Text = "Limpiar";
            this.btn_limpiar.UseVisualStyleBackColor = false;
            this.btn_limpiar.Click += new System.EventHandler(this.btn_limpiar_Click);
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Regresar.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Location = new System.Drawing.Point(364, 351);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(123, 28);
            this.btn_Regresar.TabIndex = 27;
            this.btn_Regresar.Text = "Regresar";
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(100, 118);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(549, 214);
            this.panel1.TabIndex = 28;
            // 
            // Form_Operaciones_Basicas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(750, 400);
            this.Controls.Add(this.btn_Regresar);
            this.Controls.Add(this.btn_limpiar);
            this.Controls.Add(this.txt_Resultado);
            this.Controls.Add(this.lab_Resultado);
            this.Controls.Add(this.btn_Division);
            this.Controls.Add(this.btn_multiplicacion);
            this.Controls.Add(this.btn_resta);
            this.Controls.Add(this.btn_suma);
            this.Controls.Add(this.text_Numero2);
            this.Controls.Add(this.txt_Numero1);
            this.Controls.Add(this.lab_Numero2);
            this.Controls.Add(this.lbl_Numero1);
            this.Controls.Add(this.lbl_instrucciones_Op_Bas);
            this.Controls.Add(this.panel_Menu);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_Operaciones_Basicas";
            this.Text = "Form_Operaciones_Basicas";
            this.panel_Menu.ResumeLayout(false);
            this.panel_Menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_UMI)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_Menu;
        private System.Windows.Forms.Label lbl_Operaciones_Basicas;
        private System.Windows.Forms.PictureBox picbox_UMI;
        private System.Windows.Forms.Label lbl_instrucciones_Op_Bas;
        private System.Windows.Forms.Label lbl_Numero1;
        private System.Windows.Forms.Label lab_Numero2;
        private System.Windows.Forms.TextBox txt_Numero1;
        private System.Windows.Forms.TextBox text_Numero2;
        private System.Windows.Forms.Button btn_suma;
        private System.Windows.Forms.Button btn_resta;
        private System.Windows.Forms.Button btn_multiplicacion;
        private System.Windows.Forms.Button btn_Division;
        private System.Windows.Forms.Label lab_Resultado;
        private System.Windows.Forms.TextBox txt_Resultado;
        private System.Windows.Forms.Button btn_limpiar;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Panel panel1;
    }
}