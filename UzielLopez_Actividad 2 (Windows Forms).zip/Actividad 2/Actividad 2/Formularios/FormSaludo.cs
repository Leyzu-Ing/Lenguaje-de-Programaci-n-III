﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2.Formularios
{
    public partial class FormSaludo : Form
    {
        public FormSaludo()
        {
            InitializeComponent();
        }

        private void btn_Saludar_Click(object sender, EventArgs e)
        {
            Clases.Clase_Saludo Saludo = new Clases.Clase_Saludo();
            string Misaludo = Saludo.Saludar(txt_Nombre_Saludo.Text);
            MessageBox.Show(Misaludo);
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
            Form_Menu back = new Form_Menu();
            back.Show();
        }
    }
}
