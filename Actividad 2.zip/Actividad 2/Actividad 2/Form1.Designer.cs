﻿namespace Actividad_2
{
    partial class Form_Menu
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Menu));
            this.panel_Menu = new System.Windows.Forms.Panel();
            this.lbl_Menu = new System.Windows.Forms.Label();
            this.picbox_UMI = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.Tool_Indice = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Saludo = new System.Windows.Forms.ToolStripMenuItem();
            this.datosPersonalesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.operacionesBásicasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.picbox_Universidad = new System.Windows.Forms.PictureBox();
            this.lbl_Instrucciones_menu = new System.Windows.Forms.Label();
            this.lbl_Intrucciones_Menu2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.picbox_Carita = new System.Windows.Forms.PictureBox();
            this.panel_Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_UMI)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_Universidad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_Carita)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Menu
            // 
            this.panel_Menu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel_Menu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Menu.Controls.Add(this.lbl_Menu);
            this.panel_Menu.Controls.Add(this.picbox_UMI);
            this.panel_Menu.Location = new System.Drawing.Point(-1, -1);
            this.panel_Menu.Name = "panel_Menu";
            this.panel_Menu.Size = new System.Drawing.Size(748, 100);
            this.panel_Menu.TabIndex = 0;
            // 
            // lbl_Menu
            // 
            this.lbl_Menu.AutoSize = true;
            this.lbl_Menu.Font = new System.Drawing.Font("Microsoft Tai Le", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Menu.Location = new System.Drawing.Point(318, 23);
            this.lbl_Menu.Name = "lbl_Menu";
            this.lbl_Menu.Size = new System.Drawing.Size(119, 48);
            this.lbl_Menu.TabIndex = 1;
            this.lbl_Menu.Text = "Menú";
            this.lbl_Menu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picbox_UMI
            // 
            this.picbox_UMI.Image = ((System.Drawing.Image)(resources.GetObject("picbox_UMI.Image")));
            this.picbox_UMI.Location = new System.Drawing.Point(-1, -1);
            this.picbox_UMI.Name = "picbox_UMI";
            this.picbox_UMI.Size = new System.Drawing.Size(100, 102);
            this.picbox_UMI.TabIndex = 0;
            this.picbox_UMI.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Indice});
            this.menuStrip1.Location = new System.Drawing.Point(-1, 102);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(179, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // Tool_Indice
            // 
            this.Tool_Indice.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Saludo,
            this.datosPersonalesToolStripMenuItem,
            this.operacionesBásicasToolStripMenuItem,
            this.salirToolStripMenuItem});
            this.Tool_Indice.Name = "Tool_Indice";
            this.Tool_Indice.Size = new System.Drawing.Size(51, 20);
            this.Tool_Indice.Text = "Índice";
            // 
            // Tool_Saludo
            // 
            this.Tool_Saludo.Name = "Tool_Saludo";
            this.Tool_Saludo.Size = new System.Drawing.Size(181, 22);
            this.Tool_Saludo.Text = "Saludo";
            this.Tool_Saludo.Click += new System.EventHandler(this.Tool_Saludo_Click);
            // 
            // datosPersonalesToolStripMenuItem
            // 
            this.datosPersonalesToolStripMenuItem.Name = "datosPersonalesToolStripMenuItem";
            this.datosPersonalesToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.datosPersonalesToolStripMenuItem.Text = "Datos Personales";
            this.datosPersonalesToolStripMenuItem.Click += new System.EventHandler(this.datosPersonalesToolStripMenuItem_Click);
            // 
            // operacionesBásicasToolStripMenuItem
            // 
            this.operacionesBásicasToolStripMenuItem.Name = "operacionesBásicasToolStripMenuItem";
            this.operacionesBásicasToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.operacionesBásicasToolStripMenuItem.Text = "Operaciones Básicas";
            this.operacionesBásicasToolStripMenuItem.Click += new System.EventHandler(this.operacionesBásicasToolStripMenuItem_Click);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // picbox_Universidad
            // 
            this.picbox_Universidad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picbox_Universidad.Image = ((System.Drawing.Image)(resources.GetObject("picbox_Universidad.Image")));
            this.picbox_Universidad.Location = new System.Drawing.Point(302, 102);
            this.picbox_Universidad.Name = "picbox_Universidad";
            this.picbox_Universidad.Size = new System.Drawing.Size(445, 296);
            this.picbox_Universidad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picbox_Universidad.TabIndex = 1;
            this.picbox_Universidad.TabStop = false;
            // 
            // lbl_Instrucciones_menu
            // 
            this.lbl_Instrucciones_menu.AutoSize = true;
            this.lbl_Instrucciones_menu.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Instrucciones_menu.Location = new System.Drawing.Point(51, 155);
            this.lbl_Instrucciones_menu.Name = "lbl_Instrucciones_menu";
            this.lbl_Instrucciones_menu.Size = new System.Drawing.Size(199, 21);
            this.lbl_Instrucciones_menu.TabIndex = 2;
            this.lbl_Instrucciones_menu.Text = "Este es el menú principal";
            this.lbl_Instrucciones_menu.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Intrucciones_Menu2
            // 
            this.lbl_Intrucciones_Menu2.AutoSize = true;
            this.lbl_Intrucciones_Menu2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Intrucciones_Menu2.Location = new System.Drawing.Point(34, 192);
            this.lbl_Intrucciones_Menu2.Name = "lbl_Intrucciones_Menu2";
            this.lbl_Intrucciones_Menu2.Size = new System.Drawing.Size(236, 21);
            this.lbl_Intrucciones_Menu2.TabIndex = 3;
            this.lbl_Intrucciones_Menu2.Text = "por favor elige alguna opción";
            this.lbl_Intrucciones_Menu2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 229);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 21);
            this.label1.TabIndex = 4;
            this.label1.Text = "que esta en el apartado de Índice";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picbox_Carita
            // 
            this.picbox_Carita.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picbox_Carita.Image = ((System.Drawing.Image)(resources.GetObject("picbox_Carita.Image")));
            this.picbox_Carita.Location = new System.Drawing.Point(103, 272);
            this.picbox_Carita.Name = "picbox_Carita";
            this.picbox_Carita.Size = new System.Drawing.Size(97, 98);
            this.picbox_Carita.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picbox_Carita.TabIndex = 5;
            this.picbox_Carita.TabStop = false;
            // 
            // Form_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(750, 400);
            this.Controls.Add(this.picbox_Carita);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_Intrucciones_Menu2);
            this.Controls.Add(this.lbl_Instrucciones_menu);
            this.Controls.Add(this.picbox_Universidad);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel_Menu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form_Menu";
            this.Text = "Form1";
            this.panel_Menu.ResumeLayout(false);
            this.panel_Menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_UMI)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_Universidad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_Carita)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_Menu;
        private System.Windows.Forms.Label lbl_Menu;
        private System.Windows.Forms.PictureBox picbox_UMI;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem Tool_Indice;
        private System.Windows.Forms.ToolStripMenuItem Tool_Saludo;
        private System.Windows.Forms.ToolStripMenuItem datosPersonalesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem operacionesBásicasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.PictureBox picbox_Universidad;
        private System.Windows.Forms.Label lbl_Instrucciones_menu;
        private System.Windows.Forms.Label lbl_Intrucciones_Menu2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picbox_Carita;
    }
}

