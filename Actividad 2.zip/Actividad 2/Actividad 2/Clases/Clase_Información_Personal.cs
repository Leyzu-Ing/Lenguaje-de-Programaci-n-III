﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_2.Clases
{
    public class Clase_Información_Personal
    {

        public string Guardar (string nombre)
        {
            string guardar;
            guardar = "Gracias " + nombre + " ,los datos fueron guardados";
            return guardar;
        }
    }
}
