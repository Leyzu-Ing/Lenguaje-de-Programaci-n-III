﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_2.Clases
{
    public class Clase_Operaciones_Basicas
    {
        public int Sumar (int numero1, int numero2)
        {
            int resultado;
            resultado = numero1 + numero2;
            return resultado;
        }

        public int Restar (int numero1, int numero2)
        {
            int resultado;
            resultado = numero1 - numero2;
            return resultado;
        }

        public int Multiplicar (int numero1, int numero2)
        {
            int resultado;
            resultado = numero1 * numero2;
            return resultado;
        }

        public float Division (float numero1, float numero2)
        {
            float resultado;
            resultado = numero1 / numero2;
            return resultado;
        }
        
        
            
 
    }
}
