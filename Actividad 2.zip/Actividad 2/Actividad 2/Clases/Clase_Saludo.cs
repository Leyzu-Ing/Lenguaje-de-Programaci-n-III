﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_2.Clases
{
    public class Clase_Saludo
    {
        public string Saludar (string nombre)
        {
            string saludo;
            saludo = "Hola " + nombre + " ,¿Qué tal va tu día?";
            return saludo;
        }
       
    }
}
