﻿namespace Actividad_2.Formularios
{
    partial class Form_Informacion_Personal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Informacion_Personal));
            this.panel_Info_Personal = new System.Windows.Forms.Panel();
            this.lbl_Info_Personal = new System.Windows.Forms.Label();
            this.picbox_UMI = new System.Windows.Forms.PictureBox();
            this.tabCtrl_Info_Personal = new System.Windows.Forms.TabControl();
            this.tabPage_Datos_Perso = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.radioButton_Mujer = new System.Windows.Forms.RadioButton();
            this.radioButton_Hombre = new System.Windows.Forms.RadioButton();
            this.Combox_Estado_Civil = new System.Windows.Forms.ComboBox();
            this.dateTimePicker_Fech_Nac = new System.Windows.Forms.DateTimePicker();
            this.lab_Sexo = new System.Windows.Forms.Label();
            this.lab_Estado_Civil = new System.Windows.Forms.Label();
            this.lab_Fech_Nac = new System.Windows.Forms.Label();
            this.txt_Ciudad_Info_Perso = new System.Windows.Forms.TextBox();
            this.txt_Dirección_Info_Perso = new System.Windows.Forms.TextBox();
            this.txt_Apellido_Info_Perso = new System.Windows.Forms.TextBox();
            this.txt_Nombre_Info_Perso = new System.Windows.Forms.TextBox();
            this.lab_Cuidad = new System.Windows.Forms.Label();
            this.lab_Direccion = new System.Windows.Forms.Label();
            this.lab_Apellido = new System.Windows.Forms.Label();
            this.lbl_Nombre_Info_Per = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabPage_Datos_Clinic = new System.Windows.Forms.TabPage();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_Guardar = new System.Windows.Forms.Button();
            this.comboBox_ejercicio = new System.Windows.Forms.ComboBox();
            this.comboBox_operacion = new System.Windows.Forms.ComboBox();
            this.comboBox_Alergias = new System.Windows.Forms.ComboBox();
            this.comboBox_Enfermedad = new System.Windows.Forms.ComboBox();
            this.lab_depresión = new System.Windows.Forms.Label();
            this.lab_ejercicio = new System.Windows.Forms.Label();
            this.lab_operacion = new System.Windows.Forms.Label();
            this.lab_alergia = new System.Windows.Forms.Label();
            this.lab_Enfermedad = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.panel_Info_Personal.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_UMI)).BeginInit();
            this.tabCtrl_Info_Personal.SuspendLayout();
            this.tabPage_Datos_Perso.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage_Datos_Clinic.SuspendLayout();
            this.panel3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Info_Personal
            // 
            this.panel_Info_Personal.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel_Info_Personal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Info_Personal.Controls.Add(this.lbl_Info_Personal);
            this.panel_Info_Personal.Controls.Add(this.picbox_UMI);
            this.panel_Info_Personal.Location = new System.Drawing.Point(0, 0);
            this.panel_Info_Personal.Name = "panel_Info_Personal";
            this.panel_Info_Personal.Size = new System.Drawing.Size(748, 100);
            this.panel_Info_Personal.TabIndex = 1;
            // 
            // lbl_Info_Personal
            // 
            this.lbl_Info_Personal.AutoSize = true;
            this.lbl_Info_Personal.Font = new System.Drawing.Font("Microsoft Tai Le", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Info_Personal.Location = new System.Drawing.Point(181, 21);
            this.lbl_Info_Personal.Name = "lbl_Info_Personal";
            this.lbl_Info_Personal.Size = new System.Drawing.Size(394, 48);
            this.lbl_Info_Personal.TabIndex = 1;
            this.lbl_Info_Personal.Text = "Información Personal";
            this.lbl_Info_Personal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picbox_UMI
            // 
            this.picbox_UMI.Image = ((System.Drawing.Image)(resources.GetObject("picbox_UMI.Image")));
            this.picbox_UMI.Location = new System.Drawing.Point(-1, -1);
            this.picbox_UMI.Name = "picbox_UMI";
            this.picbox_UMI.Size = new System.Drawing.Size(100, 102);
            this.picbox_UMI.TabIndex = 0;
            this.picbox_UMI.TabStop = false;
            // 
            // tabCtrl_Info_Personal
            // 
            this.tabCtrl_Info_Personal.Controls.Add(this.tabPage_Datos_Perso);
            this.tabCtrl_Info_Personal.Controls.Add(this.tabPage_Datos_Clinic);
            this.tabCtrl_Info_Personal.Location = new System.Drawing.Point(0, 106);
            this.tabCtrl_Info_Personal.Name = "tabCtrl_Info_Personal";
            this.tabCtrl_Info_Personal.SelectedIndex = 0;
            this.tabCtrl_Info_Personal.Size = new System.Drawing.Size(748, 295);
            this.tabCtrl_Info_Personal.TabIndex = 2;
            // 
            // tabPage_Datos_Perso
            // 
            this.tabPage_Datos_Perso.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.tabPage_Datos_Perso.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage_Datos_Perso.Controls.Add(this.panel2);
            this.tabPage_Datos_Perso.Controls.Add(this.txt_Ciudad_Info_Perso);
            this.tabPage_Datos_Perso.Controls.Add(this.txt_Dirección_Info_Perso);
            this.tabPage_Datos_Perso.Controls.Add(this.txt_Apellido_Info_Perso);
            this.tabPage_Datos_Perso.Controls.Add(this.txt_Nombre_Info_Perso);
            this.tabPage_Datos_Perso.Controls.Add(this.lab_Cuidad);
            this.tabPage_Datos_Perso.Controls.Add(this.lab_Direccion);
            this.tabPage_Datos_Perso.Controls.Add(this.lab_Apellido);
            this.tabPage_Datos_Perso.Controls.Add(this.lbl_Nombre_Info_Per);
            this.tabPage_Datos_Perso.Controls.Add(this.panel1);
            this.tabPage_Datos_Perso.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Datos_Perso.Name = "tabPage_Datos_Perso";
            this.tabPage_Datos_Perso.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Datos_Perso.Size = new System.Drawing.Size(740, 269);
            this.tabPage_Datos_Perso.TabIndex = 0;
            this.tabPage_Datos_Perso.Text = "Datos Personales";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.radioButton_Mujer);
            this.panel2.Controls.Add(this.radioButton_Hombre);
            this.panel2.Controls.Add(this.Combox_Estado_Civil);
            this.panel2.Controls.Add(this.dateTimePicker_Fech_Nac);
            this.panel2.Controls.Add(this.lab_Sexo);
            this.panel2.Controls.Add(this.lab_Estado_Civil);
            this.panel2.Controls.Add(this.lab_Fech_Nac);
            this.panel2.Location = new System.Drawing.Point(380, 15);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(352, 223);
            this.panel2.TabIndex = 13;
            // 
            // radioButton_Mujer
            // 
            this.radioButton_Mujer.AutoSize = true;
            this.radioButton_Mujer.Location = new System.Drawing.Point(256, 138);
            this.radioButton_Mujer.Name = "radioButton_Mujer";
            this.radioButton_Mujer.Size = new System.Drawing.Size(51, 17);
            this.radioButton_Mujer.TabIndex = 20;
            this.radioButton_Mujer.TabStop = true;
            this.radioButton_Mujer.Text = "Mujer";
            this.radioButton_Mujer.UseVisualStyleBackColor = true;
            // 
            // radioButton_Hombre
            // 
            this.radioButton_Hombre.AutoSize = true;
            this.radioButton_Hombre.Location = new System.Drawing.Point(141, 139);
            this.radioButton_Hombre.Name = "radioButton_Hombre";
            this.radioButton_Hombre.Size = new System.Drawing.Size(62, 17);
            this.radioButton_Hombre.TabIndex = 19;
            this.radioButton_Hombre.TabStop = true;
            this.radioButton_Hombre.Text = "Hombre";
            this.radioButton_Hombre.UseVisualStyleBackColor = true;
            // 
            // Combox_Estado_Civil
            // 
            this.Combox_Estado_Civil.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Combox_Estado_Civil.FormattingEnabled = true;
            this.Combox_Estado_Civil.Items.AddRange(new object[] {
            "Soltero",
            "Casado",
            "Divorciado",
            "Viudo"});
            this.Combox_Estado_Civil.Location = new System.Drawing.Point(141, 84);
            this.Combox_Estado_Civil.Name = "Combox_Estado_Civil";
            this.Combox_Estado_Civil.Size = new System.Drawing.Size(200, 24);
            this.Combox_Estado_Civil.TabIndex = 18;
            // 
            // dateTimePicker_Fech_Nac
            // 
            this.dateTimePicker_Fech_Nac.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_Fech_Nac.Location = new System.Drawing.Point(61, 42);
            this.dateTimePicker_Fech_Nac.Name = "dateTimePicker_Fech_Nac";
            this.dateTimePicker_Fech_Nac.Size = new System.Drawing.Size(236, 23);
            this.dateTimePicker_Fech_Nac.TabIndex = 17;
            // 
            // lab_Sexo
            // 
            this.lab_Sexo.AutoSize = true;
            this.lab_Sexo.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Sexo.Location = new System.Drawing.Point(3, 139);
            this.lab_Sexo.Name = "lab_Sexo";
            this.lab_Sexo.Size = new System.Drawing.Size(38, 16);
            this.lab_Sexo.TabIndex = 16;
            this.lab_Sexo.Text = "Sexo:";
            // 
            // lab_Estado_Civil
            // 
            this.lab_Estado_Civil.AutoSize = true;
            this.lab_Estado_Civil.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Estado_Civil.Location = new System.Drawing.Point(3, 90);
            this.lab_Estado_Civil.Name = "lab_Estado_Civil";
            this.lab_Estado_Civil.Size = new System.Drawing.Size(77, 16);
            this.lab_Estado_Civil.TabIndex = 15;
            this.lab_Estado_Civil.Text = "Estado Civil:";
            // 
            // lab_Fech_Nac
            // 
            this.lab_Fech_Nac.AutoSize = true;
            this.lab_Fech_Nac.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Fech_Nac.Location = new System.Drawing.Point(118, 14);
            this.lab_Fech_Nac.Name = "lab_Fech_Nac";
            this.lab_Fech_Nac.Size = new System.Drawing.Size(132, 16);
            this.lab_Fech_Nac.TabIndex = 14;
            this.lab_Fech_Nac.Text = "Fecha de Nacimiento:";
            // 
            // txt_Ciudad_Info_Perso
            // 
            this.txt_Ciudad_Info_Perso.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Ciudad_Info_Perso.Location = new System.Drawing.Point(84, 174);
            this.txt_Ciudad_Info_Perso.Name = "txt_Ciudad_Info_Perso";
            this.txt_Ciudad_Info_Perso.Size = new System.Drawing.Size(219, 23);
            this.txt_Ciudad_Info_Perso.TabIndex = 11;
            // 
            // txt_Dirección_Info_Perso
            // 
            this.txt_Dirección_Info_Perso.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Dirección_Info_Perso.Location = new System.Drawing.Point(84, 125);
            this.txt_Dirección_Info_Perso.Name = "txt_Dirección_Info_Perso";
            this.txt_Dirección_Info_Perso.Size = new System.Drawing.Size(219, 23);
            this.txt_Dirección_Info_Perso.TabIndex = 10;
            // 
            // txt_Apellido_Info_Perso
            // 
            this.txt_Apellido_Info_Perso.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Apellido_Info_Perso.Location = new System.Drawing.Point(84, 76);
            this.txt_Apellido_Info_Perso.Name = "txt_Apellido_Info_Perso";
            this.txt_Apellido_Info_Perso.Size = new System.Drawing.Size(219, 23);
            this.txt_Apellido_Info_Perso.TabIndex = 9;
            // 
            // txt_Nombre_Info_Perso
            // 
            this.txt_Nombre_Info_Perso.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nombre_Info_Perso.Location = new System.Drawing.Point(84, 27);
            this.txt_Nombre_Info_Perso.Name = "txt_Nombre_Info_Perso";
            this.txt_Nombre_Info_Perso.Size = new System.Drawing.Size(219, 23);
            this.txt_Nombre_Info_Perso.TabIndex = 8;
            // 
            // lab_Cuidad
            // 
            this.lab_Cuidad.AutoSize = true;
            this.lab_Cuidad.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Cuidad.Location = new System.Drawing.Point(19, 177);
            this.lab_Cuidad.Name = "lab_Cuidad";
            this.lab_Cuidad.Size = new System.Drawing.Size(51, 16);
            this.lab_Cuidad.TabIndex = 7;
            this.lab_Cuidad.Text = "Ciudad:";
            // 
            // lab_Direccion
            // 
            this.lab_Direccion.AutoSize = true;
            this.lab_Direccion.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Direccion.Location = new System.Drawing.Point(19, 128);
            this.lab_Direccion.Name = "lab_Direccion";
            this.lab_Direccion.Size = new System.Drawing.Size(64, 16);
            this.lab_Direccion.TabIndex = 6;
            this.lab_Direccion.Text = "Dirección:";
            // 
            // lab_Apellido
            // 
            this.lab_Apellido.AutoSize = true;
            this.lab_Apellido.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Apellido.Location = new System.Drawing.Point(19, 79);
            this.lab_Apellido.Name = "lab_Apellido";
            this.lab_Apellido.Size = new System.Drawing.Size(58, 16);
            this.lab_Apellido.TabIndex = 5;
            this.lab_Apellido.Text = "Apellido:";
            // 
            // lbl_Nombre_Info_Per
            // 
            this.lbl_Nombre_Info_Per.AutoSize = true;
            this.lbl_Nombre_Info_Per.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Nombre_Info_Per.Location = new System.Drawing.Point(19, 30);
            this.lbl_Nombre_Info_Per.Name = "lbl_Nombre_Info_Per";
            this.lbl_Nombre_Info_Per.Size = new System.Drawing.Size(59, 16);
            this.lbl_Nombre_Info_Per.TabIndex = 4;
            this.lbl_Nombre_Info_Per.Text = "Nombre:";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(7, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(352, 223);
            this.panel1.TabIndex = 12;
            // 
            // tabPage_Datos_Clinic
            // 
            this.tabPage_Datos_Clinic.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.tabPage_Datos_Clinic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage_Datos_Clinic.Controls.Add(this.btn_Regresar);
            this.tabPage_Datos_Clinic.Controls.Add(this.btn_Guardar);
            this.tabPage_Datos_Clinic.Controls.Add(this.lab_depresión);
            this.tabPage_Datos_Clinic.Controls.Add(this.lab_ejercicio);
            this.tabPage_Datos_Clinic.Controls.Add(this.lab_operacion);
            this.tabPage_Datos_Clinic.Controls.Add(this.lab_alergia);
            this.tabPage_Datos_Clinic.Controls.Add(this.lab_Enfermedad);
            this.tabPage_Datos_Clinic.Controls.Add(this.panel3);
            this.tabPage_Datos_Clinic.Controls.Add(this.groupBox1);
            this.tabPage_Datos_Clinic.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Datos_Clinic.Name = "tabPage_Datos_Clinic";
            this.tabPage_Datos_Clinic.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Datos_Clinic.Size = new System.Drawing.Size(740, 269);
            this.tabPage_Datos_Clinic.TabIndex = 1;
            this.tabPage_Datos_Clinic.Text = "Datos Clinicos";
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Regresar.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Location = new System.Drawing.Point(401, 231);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(123, 28);
            this.btn_Regresar.TabIndex = 26;
            this.btn_Regresar.Text = "Regresar";
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btn_Guardar
            // 
            this.btn_Guardar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Guardar.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Guardar.Location = new System.Drawing.Point(537, 231);
            this.btn_Guardar.Name = "btn_Guardar";
            this.btn_Guardar.Size = new System.Drawing.Size(123, 28);
            this.btn_Guardar.TabIndex = 25;
            this.btn_Guardar.Text = "Guardar";
            this.btn_Guardar.UseVisualStyleBackColor = false;
            this.btn_Guardar.Click += new System.EventHandler(this.btn_Guardar_Click);
            // 
            // comboBox_ejercicio
            // 
            this.comboBox_ejercicio.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_ejercicio.FormattingEnabled = true;
            this.comboBox_ejercicio.Items.AddRange(new object[] {
            "Una vez por semana ",
            "Tres veces por semana",
            "Cinco veces por semana",
            "Todos los días",
            "No hago ejercicio"});
            this.comboBox_ejercicio.Location = new System.Drawing.Point(346, 142);
            this.comboBox_ejercicio.Name = "comboBox_ejercicio";
            this.comboBox_ejercicio.Size = new System.Drawing.Size(247, 22);
            this.comboBox_ejercicio.TabIndex = 23;
            // 
            // comboBox_operacion
            // 
            this.comboBox_operacion.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_operacion.FormattingEnabled = true;
            this.comboBox_operacion.Items.AddRange(new object[] {
            "Apendicectomía",
            "Reparación de Hernias",
            "Reducción abierta de fractura",
            "Rinoplastia",
            "Otro",
            "Ninguna"});
            this.comboBox_operacion.Location = new System.Drawing.Point(346, 99);
            this.comboBox_operacion.Name = "comboBox_operacion";
            this.comboBox_operacion.Size = new System.Drawing.Size(247, 22);
            this.comboBox_operacion.TabIndex = 22;
            // 
            // comboBox_Alergias
            // 
            this.comboBox_Alergias.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Alergias.FormattingEnabled = true;
            this.comboBox_Alergias.Items.AddRange(new object[] {
            "Alimentos",
            "Alérgenos Ambientales",
            "Medicamentos",
            "Insectos",
            "Otro",
            "Ninguna"});
            this.comboBox_Alergias.Location = new System.Drawing.Point(346, 56);
            this.comboBox_Alergias.Name = "comboBox_Alergias";
            this.comboBox_Alergias.Size = new System.Drawing.Size(247, 22);
            this.comboBox_Alergias.TabIndex = 21;
            // 
            // comboBox_Enfermedad
            // 
            this.comboBox_Enfermedad.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox_Enfermedad.FormattingEnabled = true;
            this.comboBox_Enfermedad.Items.AddRange(new object[] {
            "Asma",
            "Úlceras",
            "Gastritis",
            "Hipertensión Arterial",
            "Otro",
            "Ninguna"});
            this.comboBox_Enfermedad.Location = new System.Drawing.Point(346, 13);
            this.comboBox_Enfermedad.Name = "comboBox_Enfermedad";
            this.comboBox_Enfermedad.Size = new System.Drawing.Size(247, 22);
            this.comboBox_Enfermedad.TabIndex = 20;
            // 
            // lab_depresión
            // 
            this.lab_depresión.AutoSize = true;
            this.lab_depresión.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_depresión.Location = new System.Drawing.Point(73, 197);
            this.lab_depresión.Name = "lab_depresión";
            this.lab_depresión.Size = new System.Drawing.Size(132, 14);
            this.lab_depresión.TabIndex = 9;
            this.lab_depresión.Text = "¿Padeces de depresión?:";
            // 
            // lab_ejercicio
            // 
            this.lab_ejercicio.AutoSize = true;
            this.lab_ejercicio.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_ejercicio.Location = new System.Drawing.Point(73, 154);
            this.lab_ejercicio.Name = "lab_ejercicio";
            this.lab_ejercicio.Size = new System.Drawing.Size(95, 14);
            this.lab_ejercicio.TabIndex = 8;
            this.lab_ejercicio.Text = "¿Haces ejercicio?:";
            // 
            // lab_operacion
            // 
            this.lab_operacion.AutoSize = true;
            this.lab_operacion.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_operacion.Location = new System.Drawing.Point(73, 111);
            this.lab_operacion.Name = "lab_operacion";
            this.lab_operacion.Size = new System.Drawing.Size(159, 14);
            this.lab_operacion.TabIndex = 7;
            this.lab_operacion.Text = "¿Alguna vez te han operado?:";
            // 
            // lab_alergia
            // 
            this.lab_alergia.AutoSize = true;
            this.lab_alergia.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_alergia.Location = new System.Drawing.Point(73, 68);
            this.lab_alergia.Name = "lab_alergia";
            this.lab_alergia.Size = new System.Drawing.Size(95, 14);
            this.lab_alergia.TabIndex = 6;
            this.lab_alergia.Text = "¿Tienes alergias?:";
            // 
            // lab_Enfermedad
            // 
            this.lab_Enfermedad.AutoSize = true;
            this.lab_Enfermedad.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Enfermedad.Location = new System.Drawing.Point(73, 25);
            this.lab_Enfermedad.Name = "lab_Enfermedad";
            this.lab_Enfermedad.Size = new System.Drawing.Size(181, 14);
            this.lab_Enfermedad.TabIndex = 5;
            this.lab_Enfermedad.Text = "¿Padeces de alguna enfermedad?:";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.groupBox6);
            this.panel3.Controls.Add(this.groupBox5);
            this.panel3.Controls.Add(this.groupBox4);
            this.panel3.Controls.Add(this.groupBox3);
            this.panel3.Controls.Add(this.groupBox2);
            this.panel3.Controls.Add(this.comboBox_ejercicio);
            this.panel3.Controls.Add(this.comboBox_Enfermedad);
            this.panel3.Controls.Add(this.comboBox_operacion);
            this.panel3.Controls.Add(this.comboBox_Alergias);
            this.panel3.Location = new System.Drawing.Point(54, 8);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(606, 220);
            this.panel3.TabIndex = 27;
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(250, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(145, 48);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Opciones ";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Location = new System.Drawing.Point(201, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(139, 42);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.radioButton3);
            this.groupBox3.Controls.Add(this.radioButton4);
            this.groupBox3.Location = new System.Drawing.Point(201, 46);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(139, 42);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.radioButton5);
            this.groupBox4.Controls.Add(this.radioButton6);
            this.groupBox4.Location = new System.Drawing.Point(201, 89);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(139, 42);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.radioButton7);
            this.groupBox5.Controls.Add(this.radioButton8);
            this.groupBox5.Location = new System.Drawing.Point(201, 132);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(139, 42);
            this.groupBox5.TabIndex = 24;
            this.groupBox5.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.radioButton9);
            this.groupBox6.Controls.Add(this.radioButton10);
            this.groupBox6.Location = new System.Drawing.Point(201, 174);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(139, 42);
            this.groupBox6.TabIndex = 25;
            this.groupBox6.TabStop = false;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(6, 14);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(39, 17);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "No";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(94, 14);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(34, 17);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Si";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(94, 13);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(34, 17);
            this.radioButton3.TabIndex = 3;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Si";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(6, 13);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(39, 17);
            this.radioButton4.TabIndex = 2;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "No";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(94, 13);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(34, 17);
            this.radioButton5.TabIndex = 5;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Si";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(6, 13);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(39, 17);
            this.radioButton6.TabIndex = 4;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "No";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Location = new System.Drawing.Point(94, 11);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(34, 17);
            this.radioButton7.TabIndex = 7;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Si";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Location = new System.Drawing.Point(6, 11);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(39, 17);
            this.radioButton8.TabIndex = 6;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "No";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Location = new System.Drawing.Point(94, 14);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(34, 17);
            this.radioButton9.TabIndex = 9;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "Si";
            this.radioButton9.UseVisualStyleBackColor = true;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(6, 14);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(39, 17);
            this.radioButton10.TabIndex = 8;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "No";
            this.radioButton10.UseVisualStyleBackColor = true;
            // 
            // Form_Informacion_Personal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(750, 400);
            this.Controls.Add(this.tabCtrl_Info_Personal);
            this.Controls.Add(this.panel_Info_Personal);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_Informacion_Personal";
            this.Text = "Form_Informacion_Personal";
            this.panel_Info_Personal.ResumeLayout(false);
            this.panel_Info_Personal.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_UMI)).EndInit();
            this.tabCtrl_Info_Personal.ResumeLayout(false);
            this.tabPage_Datos_Perso.ResumeLayout(false);
            this.tabPage_Datos_Perso.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage_Datos_Clinic.ResumeLayout(false);
            this.tabPage_Datos_Clinic.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Info_Personal;
        private System.Windows.Forms.Label lbl_Info_Personal;
        private System.Windows.Forms.PictureBox picbox_UMI;
        private System.Windows.Forms.TabControl tabCtrl_Info_Personal;
        private System.Windows.Forms.TabPage tabPage_Datos_Perso;
        private System.Windows.Forms.TabPage tabPage_Datos_Clinic;
        private System.Windows.Forms.Label lab_Cuidad;
        private System.Windows.Forms.Label lab_Direccion;
        private System.Windows.Forms.Label lab_Apellido;
        private System.Windows.Forms.Label lbl_Nombre_Info_Per;
        private System.Windows.Forms.TextBox txt_Ciudad_Info_Perso;
        private System.Windows.Forms.TextBox txt_Dirección_Info_Perso;
        private System.Windows.Forms.TextBox txt_Apellido_Info_Perso;
        private System.Windows.Forms.TextBox txt_Nombre_Info_Perso;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DateTimePicker dateTimePicker_Fech_Nac;
        private System.Windows.Forms.Label lab_Sexo;
        private System.Windows.Forms.Label lab_Estado_Civil;
        private System.Windows.Forms.Label lab_Fech_Nac;
        private System.Windows.Forms.ComboBox Combox_Estado_Civil;
        private System.Windows.Forms.RadioButton radioButton_Mujer;
        private System.Windows.Forms.RadioButton radioButton_Hombre;
        private System.Windows.Forms.Label lab_depresión;
        private System.Windows.Forms.Label lab_ejercicio;
        private System.Windows.Forms.Label lab_operacion;
        private System.Windows.Forms.Label lab_alergia;
        private System.Windows.Forms.Label lab_Enfermedad;
        private System.Windows.Forms.ComboBox comboBox_ejercicio;
        private System.Windows.Forms.ComboBox comboBox_operacion;
        private System.Windows.Forms.ComboBox comboBox_Alergias;
        private System.Windows.Forms.ComboBox comboBox_Enfermedad;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Button btn_Guardar;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
    }
}