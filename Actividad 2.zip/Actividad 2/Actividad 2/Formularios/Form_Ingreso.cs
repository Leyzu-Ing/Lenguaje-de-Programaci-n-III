﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2.Formularios
{
    public partial class Form_Ingreso : Form
    {
        public Form_Ingreso()
        {
            InitializeComponent();
        }

        private void btn_Entrar_Click(object sender, EventArgs e)
        {
            if (txt_Contraseña.Text == "")
            {
                MessageBox.Show("Favor de Ingresar una Contraseña.");
            }
            else if (txt_Contraseña.Text == "123456789")
            {
                Form_Menu form_Menu = new Form_Menu();
                form_Menu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Contraseña Incorrecta.");
                txt_Contraseña.Clear();
            }
        }
    }
}
