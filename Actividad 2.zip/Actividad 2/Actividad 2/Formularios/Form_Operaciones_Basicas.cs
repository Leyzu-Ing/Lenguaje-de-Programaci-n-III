﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2.Formularios
{
    public partial class Form_Operaciones_Basicas : Form
    {
        public Form_Operaciones_Basicas()
        {
            InitializeComponent();
            txt_Resultado.Enabled = false;
        }

        private void btn_suma_Click(object sender, EventArgs e)
        {
            int resultado;
            Clases.Clase_Operaciones_Basicas clase_Operaciones_Basicas = new Clases.Clase_Operaciones_Basicas();
            resultado = clase_Operaciones_Basicas.Sumar(int.Parse(txt_Numero1.Text), int.Parse(text_Numero2.Text));
            txt_Resultado.Text = resultado.ToString();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
            Form_Menu back = new Form_Menu();
            back.Show();
        }

        private void btn_resta_Click(object sender, EventArgs e)
        {
            int resultado;
            Clases.Clase_Operaciones_Basicas clase_Operaciones_Basicas = new Clases.Clase_Operaciones_Basicas();
            resultado = clase_Operaciones_Basicas.Restar(int.Parse(txt_Numero1.Text), int.Parse(text_Numero2.Text));
            txt_Resultado.Text = resultado.ToString();
        }

        private void btn_multiplicacion_Click(object sender, EventArgs e)
        {
            int resultado;
            Clases.Clase_Operaciones_Basicas clase_Operaciones_Basicas = new Clases.Clase_Operaciones_Basicas();
            resultado = clase_Operaciones_Basicas.Multiplicar(int.Parse(txt_Numero1.Text), int.Parse(text_Numero2.Text));
            txt_Resultado.Text = resultado.ToString();
        }

        private void btn_Division_Click(object sender, EventArgs e)
        {
            float resultado;
            Clases.Clase_Operaciones_Basicas clase_Operaciones_Basicas = new Clases.Clase_Operaciones_Basicas();
            resultado = clase_Operaciones_Basicas.Division(float.Parse(txt_Numero1.Text), float.Parse (text_Numero2.Text));
            txt_Resultado.Text = resultado.ToString();
        }

        private void btn_limpiar_Click(object sender, EventArgs e)
        {
            txt_Numero1.Clear(); 
            text_Numero2.Clear();
            txt_Resultado.Clear();
        }
    }
}
