﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2.Formularios
{
    public partial class Form_Informacion_Personal : Form
    {
        public Form_Informacion_Personal()
        {
            InitializeComponent();
        }

        private void btn_Guardar_Click(object sender, EventArgs e)
        {
            Clases.Clase_Información_Personal guardar = new Clases.Clase_Información_Personal();
            string Miguardado = guardar.Guardar(txt_Nombre_Info_Perso.Text);
            MessageBox.Show(Miguardado);
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
            Form_Menu back = new Form_Menu();
            back.Show();
        }
    }
}
