﻿namespace Actividad_2.Formularios
{
    partial class Form_Ingreso
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Ingreso));
            this.panel_Menu = new System.Windows.Forms.Panel();
            this.lbl_Ingreso = new System.Windows.Forms.Label();
            this.picbox_UMI = new System.Windows.Forms.PictureBox();
            this.lbl_instrucciones_Op_Bas = new System.Windows.Forms.Label();
            this.lbl_Contraseña = new System.Windows.Forms.Label();
            this.txt_Contraseña = new System.Windows.Forms.TextBox();
            this.btn_Entrar = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel_Menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_UMI)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_Menu
            // 
            this.panel_Menu.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel_Menu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_Menu.Controls.Add(this.lbl_Ingreso);
            this.panel_Menu.Controls.Add(this.picbox_UMI);
            this.panel_Menu.Location = new System.Drawing.Point(0, 0);
            this.panel_Menu.Name = "panel_Menu";
            this.panel_Menu.Size = new System.Drawing.Size(748, 100);
            this.panel_Menu.TabIndex = 2;
            // 
            // lbl_Ingreso
            // 
            this.lbl_Ingreso.AutoSize = true;
            this.lbl_Ingreso.Font = new System.Drawing.Font("Microsoft Tai Le", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Ingreso.Location = new System.Drawing.Point(303, 25);
            this.lbl_Ingreso.Name = "lbl_Ingreso";
            this.lbl_Ingreso.Size = new System.Drawing.Size(151, 48);
            this.lbl_Ingreso.TabIndex = 1;
            this.lbl_Ingreso.Text = "Ingreso";
            this.lbl_Ingreso.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // picbox_UMI
            // 
            this.picbox_UMI.Image = ((System.Drawing.Image)(resources.GetObject("picbox_UMI.Image")));
            this.picbox_UMI.Location = new System.Drawing.Point(-1, -1);
            this.picbox_UMI.Name = "picbox_UMI";
            this.picbox_UMI.Size = new System.Drawing.Size(100, 102);
            this.picbox_UMI.TabIndex = 0;
            this.picbox_UMI.TabStop = false;
            // 
            // lbl_instrucciones_Op_Bas
            // 
            this.lbl_instrucciones_Op_Bas.AutoSize = true;
            this.lbl_instrucciones_Op_Bas.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_instrucciones_Op_Bas.Location = new System.Drawing.Point(14, 15);
            this.lbl_instrucciones_Op_Bas.Name = "lbl_instrucciones_Op_Bas";
            this.lbl_instrucciones_Op_Bas.Size = new System.Drawing.Size(453, 19);
            this.lbl_instrucciones_Op_Bas.TabIndex = 6;
            this.lbl_instrucciones_Op_Bas.Text = "Para ingresar a la aplicación, es necesario ingresar la contraseña";
            // 
            // lbl_Contraseña
            // 
            this.lbl_Contraseña.AutoSize = true;
            this.lbl_Contraseña.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Contraseña.Location = new System.Drawing.Point(209, 51);
            this.lbl_Contraseña.Name = "lbl_Contraseña";
            this.lbl_Contraseña.Size = new System.Drawing.Size(86, 19);
            this.lbl_Contraseña.TabIndex = 7;
            this.lbl_Contraseña.Text = "Contraseña:";
            // 
            // txt_Contraseña
            // 
            this.txt_Contraseña.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Contraseña.Location = new System.Drawing.Point(106, 82);
            this.txt_Contraseña.Name = "txt_Contraseña";
            this.txt_Contraseña.PasswordChar = '*';
            this.txt_Contraseña.Size = new System.Drawing.Size(293, 27);
            this.txt_Contraseña.TabIndex = 8;
            this.txt_Contraseña.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Entrar
            // 
            this.btn_Entrar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Entrar.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Entrar.Location = new System.Drawing.Point(191, 126);
            this.btn_Entrar.Name = "btn_Entrar";
            this.btn_Entrar.Size = new System.Drawing.Size(123, 28);
            this.btn_Entrar.TabIndex = 27;
            this.btn_Entrar.Text = "Entrar";
            this.btn_Entrar.UseVisualStyleBackColor = false;
            this.btn_Entrar.Click += new System.EventHandler(this.btn_Entrar_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btn_Entrar);
            this.panel1.Controls.Add(this.txt_Contraseña);
            this.panel1.Controls.Add(this.lbl_instrucciones_Op_Bas);
            this.panel1.Controls.Add(this.lbl_Contraseña);
            this.panel1.Location = new System.Drawing.Point(129, 127);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(487, 175);
            this.panel1.TabIndex = 28;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(318, 317);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(127, 59);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 29;
            this.pictureBox1.TabStop = false;
            // 
            // Form_Ingreso
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(750, 400);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel_Menu);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_Ingreso";
            this.Text = "Form_Ingreso";
            this.panel_Menu.ResumeLayout(false);
            this.panel_Menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picbox_UMI)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Menu;
        private System.Windows.Forms.Label lbl_Ingreso;
        private System.Windows.Forms.PictureBox picbox_UMI;
        private System.Windows.Forms.Label lbl_instrucciones_Op_Bas;
        private System.Windows.Forms.Label lbl_Contraseña;
        private System.Windows.Forms.TextBox txt_Contraseña;
        private System.Windows.Forms.Button btn_Entrar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}