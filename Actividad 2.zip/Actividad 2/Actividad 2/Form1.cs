﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_2
{
    public partial class Form_Menu : Form
    {
        public Form_Menu()
        {
            InitializeComponent();
        }

        private void Tool_Saludo_Click(object sender, EventArgs e)
        {
            Formularios.FormSaludo FormSaludo = new Formularios.FormSaludo();
            FormSaludo.Show();
            this.Hide();
        }

        private void datosPersonalesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.Form_Informacion_Personal Form_Informacion_Personal = new Formularios.Form_Informacion_Personal();
            Form_Informacion_Personal.Show();
            this.Hide();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void operacionesBásicasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.Form_Operaciones_Basicas Form_Operaciones_Basicas = new Formularios.Form_Operaciones_Basicas();
            Form_Operaciones_Basicas.Show();
            this.Hide();
        }
    }
}
