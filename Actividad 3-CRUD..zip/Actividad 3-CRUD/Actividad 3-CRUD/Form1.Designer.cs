﻿namespace Actividad_3_CRUD
{
    partial class Form_Menú
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Menú));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lab_Menú_Titulo = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.bienvenidaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tool_Mensaje_Bienvenida = new System.Windows.Forms.ToolStripMenuItem();
            this.tool_Quienes_Somos = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Misión = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Vision = new System.Windows.Forms.ToolStripMenuItem();
            this.productosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Damas = new System.Windows.Forms.ToolStripMenuItem();
            this.caballerosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.registroToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Cliente = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Proveedor = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Producto = new System.Windows.Forms.ToolStripMenuItem();
            this.Tool_Compras = new System.Windows.Forms.ToolStripMenuItem();
            this.salirToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lab_Menú_Titulo);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(753, 100);
            this.panel1.TabIndex = 0;
            // 
            // lab_Menú_Titulo
            // 
            this.lab_Menú_Titulo.AutoSize = true;
            this.lab_Menú_Titulo.Font = new System.Drawing.Font("Microsoft Tai Le", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Menú_Titulo.Location = new System.Drawing.Point(194, 30);
            this.lab_Menú_Titulo.Name = "lab_Menú_Titulo";
            this.lab_Menú_Titulo.Size = new System.Drawing.Size(352, 41);
            this.lab_Menú_Titulo.TabIndex = 1;
            this.lab_Menú_Titulo.Text = "Zapateria la Esperanza";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 102);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bienvenidaToolStripMenuItem,
            this.productosToolStripMenuItem1,
            this.registroToolStripMenuItem1,
            this.Tool_Compras,
            this.salirToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 101);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(448, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // bienvenidaToolStripMenuItem
            // 
            this.bienvenidaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tool_Mensaje_Bienvenida,
            this.tool_Quienes_Somos,
            this.Tool_Misión,
            this.Tool_Vision});
            this.bienvenidaToolStripMenuItem.Name = "bienvenidaToolStripMenuItem";
            this.bienvenidaToolStripMenuItem.Size = new System.Drawing.Size(77, 20);
            this.bienvenidaToolStripMenuItem.Text = "Bienvenida";
            // 
            // tool_Mensaje_Bienvenida
            // 
            this.tool_Mensaje_Bienvenida.Name = "tool_Mensaje_Bienvenida";
            this.tool_Mensaje_Bienvenida.Size = new System.Drawing.Size(195, 22);
            this.tool_Mensaje_Bienvenida.Text = "Mensaje de Bienvenida";
            this.tool_Mensaje_Bienvenida.Click += new System.EventHandler(this.tool_Mensaje_Bienvenida_Click);
            // 
            // tool_Quienes_Somos
            // 
            this.tool_Quienes_Somos.Name = "tool_Quienes_Somos";
            this.tool_Quienes_Somos.Size = new System.Drawing.Size(195, 22);
            this.tool_Quienes_Somos.Text = "¿Quiénes Somos?";
            this.tool_Quienes_Somos.Click += new System.EventHandler(this.tool_Quienes_Somos_Click);
            // 
            // Tool_Misión
            // 
            this.Tool_Misión.Name = "Tool_Misión";
            this.Tool_Misión.Size = new System.Drawing.Size(195, 22);
            this.Tool_Misión.Text = "Misión";
            this.Tool_Misión.Click += new System.EventHandler(this.Tool_Misión_Click);
            // 
            // Tool_Vision
            // 
            this.Tool_Vision.Name = "Tool_Vision";
            this.Tool_Vision.Size = new System.Drawing.Size(195, 22);
            this.Tool_Vision.Text = "Visión";
            this.Tool_Vision.Click += new System.EventHandler(this.Tool_Vision_Click);
            // 
            // productosToolStripMenuItem1
            // 
            this.productosToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Damas,
            this.caballerosToolStripMenuItem});
            this.productosToolStripMenuItem1.Name = "productosToolStripMenuItem1";
            this.productosToolStripMenuItem1.Size = new System.Drawing.Size(73, 20);
            this.productosToolStripMenuItem1.Text = "Productos";
            // 
            // Tool_Damas
            // 
            this.Tool_Damas.Name = "Tool_Damas";
            this.Tool_Damas.Size = new System.Drawing.Size(129, 22);
            this.Tool_Damas.Text = "Damas";
            this.Tool_Damas.Click += new System.EventHandler(this.Tool_Damas_Click);
            // 
            // caballerosToolStripMenuItem
            // 
            this.caballerosToolStripMenuItem.Name = "caballerosToolStripMenuItem";
            this.caballerosToolStripMenuItem.Size = new System.Drawing.Size(129, 22);
            this.caballerosToolStripMenuItem.Text = "Caballeros";
            this.caballerosToolStripMenuItem.Click += new System.EventHandler(this.caballerosToolStripMenuItem_Click);
            // 
            // registroToolStripMenuItem1
            // 
            this.registroToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tool_Cliente,
            this.Tool_Proveedor,
            this.Tool_Producto});
            this.registroToolStripMenuItem1.Name = "registroToolStripMenuItem1";
            this.registroToolStripMenuItem1.Size = new System.Drawing.Size(62, 20);
            this.registroToolStripMenuItem1.Text = "Registro";
            // 
            // Tool_Cliente
            // 
            this.Tool_Cliente.Name = "Tool_Cliente";
            this.Tool_Cliente.Size = new System.Drawing.Size(128, 22);
            this.Tool_Cliente.Text = "Cliente";
            this.Tool_Cliente.Click += new System.EventHandler(this.Tool_Cliente_Click);
            // 
            // Tool_Proveedor
            // 
            this.Tool_Proveedor.Name = "Tool_Proveedor";
            this.Tool_Proveedor.Size = new System.Drawing.Size(128, 22);
            this.Tool_Proveedor.Text = "Proveedor";
            this.Tool_Proveedor.Click += new System.EventHandler(this.Tool_Proveedor_Click);
            // 
            // Tool_Producto
            // 
            this.Tool_Producto.Name = "Tool_Producto";
            this.Tool_Producto.Size = new System.Drawing.Size(128, 22);
            this.Tool_Producto.Text = "Producto";
            this.Tool_Producto.Click += new System.EventHandler(this.Tool_Producto_Click);
            // 
            // Tool_Compras
            // 
            this.Tool_Compras.Name = "Tool_Compras";
            this.Tool_Compras.Size = new System.Drawing.Size(67, 20);
            this.Tool_Compras.Text = "Compras";
            this.Tool_Compras.Click += new System.EventHandler(this.Tool_Compras_Click);
            // 
            // salirToolStripMenuItem1
            // 
            this.salirToolStripMenuItem1.Name = "salirToolStripMenuItem1";
            this.salirToolStripMenuItem1.Size = new System.Drawing.Size(41, 20);
            this.salirToolStripMenuItem1.Text = "Salir";
            this.salirToolStripMenuItem1.Click += new System.EventHandler(this.salirToolStripMenuItem1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(331, 101);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(422, 348);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(27, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(286, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "Bienvenido a Zapateria la Esperanza";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(51, 211);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(236, 21);
            this.label2.TabIndex = 4;
            this.label2.Text = "por favor elige alguna opción";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(55, 263);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(229, 148);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // Form_Menú
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(750, 450);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form_Menú";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lab_Menú_Titulo;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem bienvenidaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tool_Mensaje_Bienvenida;
        private System.Windows.Forms.ToolStripMenuItem tool_Quienes_Somos;
        private System.Windows.Forms.ToolStripMenuItem Tool_Misión;
        private System.Windows.Forms.ToolStripMenuItem Tool_Vision;
        private System.Windows.Forms.ToolStripMenuItem productosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem Tool_Damas;
        private System.Windows.Forms.ToolStripMenuItem caballerosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem registroToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem Tool_Cliente;
        private System.Windows.Forms.ToolStripMenuItem Tool_Proveedor;
        private System.Windows.Forms.ToolStripMenuItem Tool_Producto;
        private System.Windows.Forms.ToolStripMenuItem Tool_Compras;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}

