﻿namespace Actividad_3_CRUD.Formularios
{
    partial class Form_Compra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Compra));
            this.lab_Cliente = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lab_Numero1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Numero1 = new System.Windows.Forms.TextBox();
            this.txt_Numero2 = new System.Windows.Forms.TextBox();
            this.btn_Suma = new System.Windows.Forms.Button();
            this.btn_Resta = new System.Windows.Forms.Button();
            this.btn_Multiplicación = new System.Windows.Forms.Button();
            this.btn_División = new System.Windows.Forms.Button();
            this.lab_Resultado = new System.Windows.Forms.Label();
            this.txt_Resultado = new System.Windows.Forms.TextBox();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.btn_Limpiar = new System.Windows.Forms.Button();
            this.btn_Mostrar = new System.Windows.Forms.Button();
            this.dgv_Compra = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Compra)).BeginInit();
            this.SuspendLayout();
            // 
            // lab_Cliente
            // 
            this.lab_Cliente.AutoSize = true;
            this.lab_Cliente.Font = new System.Drawing.Font("Microsoft Tai Le", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Cliente.Location = new System.Drawing.Point(301, 30);
            this.lab_Cliente.Name = "lab_Cliente";
            this.lab_Cliente.Size = new System.Drawing.Size(151, 41);
            this.lab_Cliente.TabIndex = 1;
            this.lab_Cliente.Text = "Compras";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 102);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lab_Cliente);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(753, 100);
            this.panel1.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(81, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(583, 21);
            this.label1.TabIndex = 17;
            this.label1.Text = "Aqui tienes una calculadora basica en la que puedes gestionar tus compras.";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btn_Limpiar);
            this.panel2.Controls.Add(this.btn_Regresar);
            this.panel2.Controls.Add(this.txt_Resultado);
            this.panel2.Controls.Add(this.lab_Resultado);
            this.panel2.Controls.Add(this.btn_División);
            this.panel2.Controls.Add(this.btn_Multiplicación);
            this.panel2.Controls.Add(this.btn_Resta);
            this.panel2.Controls.Add(this.btn_Suma);
            this.panel2.Controls.Add(this.txt_Numero2);
            this.panel2.Controls.Add(this.txt_Numero1);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.lab_Numero1);
            this.panel2.Location = new System.Drawing.Point(12, 108);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(726, 187);
            this.panel2.TabIndex = 18;
            // 
            // lab_Numero1
            // 
            this.lab_Numero1.AutoSize = true;
            this.lab_Numero1.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Numero1.Location = new System.Drawing.Point(229, 47);
            this.lab_Numero1.Name = "lab_Numero1";
            this.lab_Numero1.Size = new System.Drawing.Size(78, 19);
            this.lab_Numero1.TabIndex = 0;
            this.lab_Numero1.Text = "Número 1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(229, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Número 2:";
            // 
            // txt_Numero1
            // 
            this.txt_Numero1.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Numero1.Location = new System.Drawing.Point(314, 46);
            this.txt_Numero1.Name = "txt_Numero1";
            this.txt_Numero1.Size = new System.Drawing.Size(141, 24);
            this.txt_Numero1.TabIndex = 2;
            this.txt_Numero1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Numero2
            // 
            this.txt_Numero2.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Numero2.Location = new System.Drawing.Point(313, 83);
            this.txt_Numero2.Name = "txt_Numero2";
            this.txt_Numero2.Size = new System.Drawing.Size(142, 24);
            this.txt_Numero2.TabIndex = 3;
            this.txt_Numero2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Suma
            // 
            this.btn_Suma.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn_Suma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Suma.Location = new System.Drawing.Point(25, 113);
            this.btn_Suma.Name = "btn_Suma";
            this.btn_Suma.Size = new System.Drawing.Size(82, 26);
            this.btn_Suma.TabIndex = 4;
            this.btn_Suma.Text = "Suma";
            this.btn_Suma.UseVisualStyleBackColor = false;
            this.btn_Suma.Click += new System.EventHandler(this.btn_Suma_Click);
            // 
            // btn_Resta
            // 
            this.btn_Resta.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn_Resta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Resta.Location = new System.Drawing.Point(212, 113);
            this.btn_Resta.Name = "btn_Resta";
            this.btn_Resta.Size = new System.Drawing.Size(82, 26);
            this.btn_Resta.TabIndex = 5;
            this.btn_Resta.Text = "Resta";
            this.btn_Resta.UseVisualStyleBackColor = false;
            this.btn_Resta.Click += new System.EventHandler(this.btn_Resta_Click);
            // 
            // btn_Multiplicación
            // 
            this.btn_Multiplicación.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn_Multiplicación.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Multiplicación.Location = new System.Drawing.Point(399, 113);
            this.btn_Multiplicación.Name = "btn_Multiplicación";
            this.btn_Multiplicación.Size = new System.Drawing.Size(109, 26);
            this.btn_Multiplicación.TabIndex = 6;
            this.btn_Multiplicación.Text = "Multiplicación";
            this.btn_Multiplicación.UseVisualStyleBackColor = false;
            this.btn_Multiplicación.Click += new System.EventHandler(this.btn_Multiplicación_Click);
            // 
            // btn_División
            // 
            this.btn_División.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btn_División.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_División.Location = new System.Drawing.Point(613, 113);
            this.btn_División.Name = "btn_División";
            this.btn_División.Size = new System.Drawing.Size(82, 26);
            this.btn_División.TabIndex = 7;
            this.btn_División.Text = "División";
            this.btn_División.UseVisualStyleBackColor = false;
            this.btn_División.Click += new System.EventHandler(this.btn_División_Click);
            // 
            // lab_Resultado
            // 
            this.lab_Resultado.AutoSize = true;
            this.lab_Resultado.Font = new System.Drawing.Font("Microsoft Tai Le", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Resultado.Location = new System.Drawing.Point(229, 157);
            this.lab_Resultado.Name = "lab_Resultado";
            this.lab_Resultado.Size = new System.Drawing.Size(78, 19);
            this.lab_Resultado.TabIndex = 8;
            this.lab_Resultado.Text = "Resultado:";
            // 
            // txt_Resultado
            // 
            this.txt_Resultado.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Resultado.Location = new System.Drawing.Point(314, 152);
            this.txt_Resultado.Name = "txt_Resultado";
            this.txt_Resultado.Size = new System.Drawing.Size(142, 24);
            this.txt_Resultado.TabIndex = 9;
            this.txt_Resultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Regresar.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Location = new System.Drawing.Point(15, 150);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(161, 33);
            this.btn_Regresar.TabIndex = 21;
            this.btn_Regresar.Text = "Regresar";
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // btn_Limpiar
            // 
            this.btn_Limpiar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Limpiar.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Limpiar.Location = new System.Drawing.Point(560, 150);
            this.btn_Limpiar.Name = "btn_Limpiar";
            this.btn_Limpiar.Size = new System.Drawing.Size(161, 33);
            this.btn_Limpiar.TabIndex = 22;
            this.btn_Limpiar.Text = "Limpiar";
            this.btn_Limpiar.UseVisualStyleBackColor = false;
            this.btn_Limpiar.Click += new System.EventHandler(this.btn_Limpiar_Click);
            // 
            // btn_Mostrar
            // 
            this.btn_Mostrar.BackColor = System.Drawing.Color.CadetBlue;
            this.btn_Mostrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Mostrar.Location = new System.Drawing.Point(315, 301);
            this.btn_Mostrar.Name = "btn_Mostrar";
            this.btn_Mostrar.Size = new System.Drawing.Size(109, 26);
            this.btn_Mostrar.TabIndex = 23;
            this.btn_Mostrar.Text = "Mostrar";
            this.btn_Mostrar.UseVisualStyleBackColor = false;
            this.btn_Mostrar.Click += new System.EventHandler(this.btn_Mostrar_Click);
            // 
            // dgv_Compra
            // 
            this.dgv_Compra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Compra.Location = new System.Drawing.Point(12, 333);
            this.dgv_Compra.Name = "dgv_Compra";
            this.dgv_Compra.Size = new System.Drawing.Size(726, 205);
            this.dgv_Compra.TabIndex = 24;
            // 
            // Form_Compra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(750, 550);
            this.Controls.Add(this.dgv_Compra);
            this.Controls.Add(this.btn_Mostrar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_Compra";
            this.Text = "Form_Compra";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Compra)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_Cliente;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_División;
        private System.Windows.Forms.Button btn_Multiplicación;
        private System.Windows.Forms.Button btn_Resta;
        private System.Windows.Forms.Button btn_Suma;
        private System.Windows.Forms.TextBox txt_Numero2;
        private System.Windows.Forms.TextBox txt_Numero1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lab_Numero1;
        private System.Windows.Forms.TextBox txt_Resultado;
        private System.Windows.Forms.Label lab_Resultado;
        private System.Windows.Forms.Button btn_Limpiar;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.Button btn_Mostrar;
        private System.Windows.Forms.DataGridView dgv_Compra;
    }
}