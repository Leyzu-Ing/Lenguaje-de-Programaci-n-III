﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad_3_CRUD.Formularios
{
    public partial class Form_Registro_Producto : Form
    {
        public Form_Registro_Producto()
        {
            InitializeComponent();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
            Form_Menú back = new Form_Menú();
            back.Show();
        }

        private void Form_Registro_Producto_Load(object sender, EventArgs e)
        {

        }

        private void btn_Agregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO Producto ( Género, Marca, Tipo, Talla) VALUES ('"+txt_Genero.Text + "', '"+txt_Marca.Text + "', '"+txt_Tipo.Text + "', '"+txt_Talla.Text + "')", Conexion);
                cmd.CommandType = CommandType.Text;
                Conexion.Open();
                cmd.ExecuteNonQuery();

                txt_Genero.Clear();
                txt_Marca.Clear();
                txt_Tipo.Clear();
                txt_Talla.Clear();

                MessageBox.Show("El Producto se ha Agregado correctamente");

            }
        }

        private void btn_Modificar_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Producto SET Género = '"+ txt_Genero.Text + "', Marca = '" + txt_Marca.Text + "', Talla = '"+ txt_Talla.Text + "' Where Tipo = '" + txt_Tipo.Text + "' ", Conexion);
                cmd.CommandType = CommandType.Text;
                Conexion.Open();
                cmd.ExecuteNonQuery();

                txt_Genero.Clear();
                txt_Marca.Clear();
                txt_Tipo.Clear();
                txt_Talla.Clear();

                MessageBox.Show("El Producto se ha Modificado Correctamente. ");

            }
        }

        private void btn_Eliminar_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Producto Where Tipo = '" + txt_Tipo.Text + "'", Conexion);
                cmd.CommandType = CommandType.Text;
                Conexion.Open();
                cmd.ExecuteNonQuery();

                txt_Genero.Clear();
                txt_Marca.Clear();
                txt_Tipo.Clear();
                txt_Talla.Clear();

                MessageBox.Show("El Producto se ha Eliminado Correctamente. ");

            }
        }

        private void btn_Mostrar_Click(object sender, EventArgs e)
        {
            DataTable DT = new DataTable();
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter Data = new SqlDataAdapter("Select * from Producto", Conexion);
                Data.SelectCommand.CommandType = CommandType.Text; ;

                Conexion.Open();
                Data.Fill(DT);

                dgv_Productos.DataSource = DT;
            }
        }
    }
}
