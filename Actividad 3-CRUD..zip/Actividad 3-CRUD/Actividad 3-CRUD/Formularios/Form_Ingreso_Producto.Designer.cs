﻿namespace Actividad_3_CRUD.Formularios
{
    partial class Form_Ingreso_Producto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Ingreso_Producto));
            this.lab_Damas = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_Entrar_Cliente = new System.Windows.Forms.Button();
            this.txt_Contraseña_Producto = new System.Windows.Forms.TextBox();
            this.lab_Contraseña_Cliente = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lab_Damas
            // 
            this.lab_Damas.AutoSize = true;
            this.lab_Damas.Font = new System.Drawing.Font("Microsoft Tai Le", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Damas.Location = new System.Drawing.Point(309, 30);
            this.lab_Damas.Name = "lab_Damas";
            this.lab_Damas.Size = new System.Drawing.Size(131, 41);
            this.lab_Damas.TabIndex = 1;
            this.lab_Damas.Text = "Ingreso";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 102);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lab_Damas);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(753, 100);
            this.panel1.TabIndex = 9;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(309, 363);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(141, 83);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 34;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(237, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(267, 21);
            this.label3.TabIndex = 32;
            this.label3.Text = "el Supervisor Encargado de turno.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(198, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(353, 21);
            this.label2.TabIndex = 31;
            this.label2.Text = "necesario escribir la contraseña otorgada por";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(160, 135);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(428, 21);
            this.label1.TabIndex = 30;
            this.label1.Text = "Para ingresar al apartado de \"Registro de Producto\", es";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btn_Entrar_Cliente);
            this.panel2.Controls.Add(this.txt_Contraseña_Producto);
            this.panel2.Controls.Add(this.lab_Contraseña_Cliente);
            this.panel2.Location = new System.Drawing.Point(151, 119);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(446, 242);
            this.panel2.TabIndex = 33;
            // 
            // btn_Entrar_Cliente
            // 
            this.btn_Entrar_Cliente.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Entrar_Cliente.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Entrar_Cliente.Location = new System.Drawing.Point(145, 187);
            this.btn_Entrar_Cliente.Name = "btn_Entrar_Cliente";
            this.btn_Entrar_Cliente.Size = new System.Drawing.Size(161, 33);
            this.btn_Entrar_Cliente.TabIndex = 23;
            this.btn_Entrar_Cliente.Text = "Entrar";
            this.btn_Entrar_Cliente.UseVisualStyleBackColor = false;
            this.btn_Entrar_Cliente.Click += new System.EventHandler(this.btn_Entrar_Cliente_Click);
            // 
            // txt_Contraseña_Producto
            // 
            this.txt_Contraseña_Producto.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Contraseña_Producto.Location = new System.Drawing.Point(123, 143);
            this.txt_Contraseña_Producto.Name = "txt_Contraseña_Producto";
            this.txt_Contraseña_Producto.PasswordChar = '*';
            this.txt_Contraseña_Producto.Size = new System.Drawing.Size(204, 28);
            this.txt_Contraseña_Producto.TabIndex = 1;
            // 
            // lab_Contraseña_Cliente
            // 
            this.lab_Contraseña_Cliente.AutoSize = true;
            this.lab_Contraseña_Cliente.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Contraseña_Cliente.Location = new System.Drawing.Point(177, 119);
            this.lab_Contraseña_Cliente.Name = "lab_Contraseña_Cliente";
            this.lab_Contraseña_Cliente.Size = new System.Drawing.Size(92, 21);
            this.lab_Contraseña_Cliente.TabIndex = 0;
            this.lab_Contraseña_Cliente.Text = "Contraseña:";
            // 
            // Form_Ingreso_Producto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(750, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_Ingreso_Producto";
            this.Text = "Form_Ingreso_Producto";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lab_Damas;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btn_Entrar_Cliente;
        private System.Windows.Forms.TextBox txt_Contraseña_Producto;
        private System.Windows.Forms.Label lab_Contraseña_Cliente;
    }
}