﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad_3_CRUD.Formularios
{
    public partial class Form_Compra : Form
    {
        public Form_Compra()
        {
            InitializeComponent();
            txt_Resultado.Enabled = false;
        }

        private void btn_Suma_Click(object sender, EventArgs e)
        {
            float resultado;
            Clases.Clase_Compra clase_Compra = new Clases.Clase_Compra();
            resultado = clase_Compra.Sumar(float.Parse(txt_Numero1.Text), float.Parse(txt_Numero2.Text));
            txt_Resultado.Text = resultado.ToString();
        }

        private void btn_Resta_Click(object sender, EventArgs e)
        {
            float resultado;
            Clases.Clase_Compra clase_Compra = new Clases.Clase_Compra();
            resultado = clase_Compra.Restar(float.Parse(txt_Numero1.Text), float.Parse(txt_Numero2.Text));
            txt_Resultado.Text = resultado.ToString();
        }

        private void btn_Multiplicación_Click(object sender, EventArgs e)
        {
            float resultado;
            Clases.Clase_Compra clase_Compra = new Clases.Clase_Compra();
            resultado = clase_Compra.Multiplicar(float.Parse(txt_Numero1.Text), float.Parse(txt_Numero2.Text));
            txt_Resultado.Text = resultado.ToString();
        }

        private void btn_División_Click(object sender, EventArgs e)
        {
            float resultado;
            Clases.Clase_Compra clase_Compra = new Clases.Clase_Compra();
            resultado = clase_Compra.Dividir(float.Parse(txt_Numero1.Text), float.Parse(txt_Numero2.Text));
            txt_Resultado.Text = resultado.ToString();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
            Form_Menú back = new Form_Menú();
            back.Show();
        }

        private void btn_Limpiar_Click(object sender, EventArgs e)
        {
            txt_Numero1.Clear();
            txt_Numero2.Clear();
            txt_Resultado.Clear();
        }

        private void btn_Mostrar_Click(object sender, EventArgs e)
        {
            DataTable DT = new DataTable();
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter Data = new SqlDataAdapter("Select * from Compra", Conexion);
                Data.SelectCommand.CommandType = CommandType.Text; ;

                Conexion.Open();
                Data.Fill(DT);

                dgv_Compra.DataSource = DT;
            }
        }
    }
}
