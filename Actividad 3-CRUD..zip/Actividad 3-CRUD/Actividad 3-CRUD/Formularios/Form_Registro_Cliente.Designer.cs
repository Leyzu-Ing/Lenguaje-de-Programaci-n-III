﻿namespace Actividad_3_CRUD.Formularios
{
    partial class Form_Registro_Cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Registro_Cliente));
            this.lab_Cliente = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gb_Datos_Personales = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_Fecha_Nac = new System.Windows.Forms.TextBox();
            this.txt_Telefono = new System.Windows.Forms.TextBox();
            this.txt_ApellidoMat = new System.Windows.Forms.TextBox();
            this.txt_ApellidoPat = new System.Windows.Forms.TextBox();
            this.txt_Nombre_Cliente = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn_Agregar_Cliente = new System.Windows.Forms.Button();
            this.btn_Modificar_Cliente = new System.Windows.Forms.Button();
            this.btn_Mostrar_Cliente = new System.Windows.Forms.Button();
            this.btn_Eliminar_Cliente = new System.Windows.Forms.Button();
            this.btn_Regresar = new System.Windows.Forms.Button();
            this.dgv_Cliente = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.gb_Datos_Personales.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Cliente)).BeginInit();
            this.SuspendLayout();
            // 
            // lab_Cliente
            // 
            this.lab_Cliente.AutoSize = true;
            this.lab_Cliente.Font = new System.Drawing.Font("Microsoft Tai Le", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_Cliente.Location = new System.Drawing.Point(240, 30);
            this.lab_Cliente.Name = "lab_Cliente";
            this.lab_Cliente.Size = new System.Drawing.Size(302, 41);
            this.lab_Cliente.TabIndex = 1;
            this.lab_Cliente.Text = "Registro de Cliente";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 102);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lab_Cliente);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(-1, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(753, 100);
            this.panel1.TabIndex = 8;
            // 
            // gb_Datos_Personales
            // 
            this.gb_Datos_Personales.BackColor = System.Drawing.SystemColors.ControlLight;
            this.gb_Datos_Personales.Controls.Add(this.txt_Nombre_Cliente);
            this.gb_Datos_Personales.Controls.Add(this.txt_ApellidoPat);
            this.gb_Datos_Personales.Controls.Add(this.txt_ApellidoMat);
            this.gb_Datos_Personales.Controls.Add(this.txt_Telefono);
            this.gb_Datos_Personales.Controls.Add(this.txt_Fecha_Nac);
            this.gb_Datos_Personales.Controls.Add(this.label5);
            this.gb_Datos_Personales.Controls.Add(this.label4);
            this.gb_Datos_Personales.Controls.Add(this.label3);
            this.gb_Datos_Personales.Controls.Add(this.label2);
            this.gb_Datos_Personales.Controls.Add(this.label1);
            this.gb_Datos_Personales.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_Datos_Personales.Location = new System.Drawing.Point(7, 106);
            this.gb_Datos_Personales.Name = "gb_Datos_Personales";
            this.gb_Datos_Personales.Size = new System.Drawing.Size(480, 181);
            this.gb_Datos_Personales.TabIndex = 9;
            this.gb_Datos_Personales.TabStop = false;
            this.gb_Datos_Personales.Text = "Datos Personales";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre(s):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Apellido Paterno:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Apellido Materno:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(213, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Fecha de Nacimiento (AAAA-MM-DD):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Tai Le", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Telefono:";
            // 
            // txt_Fecha_Nac
            // 
            this.txt_Fecha_Nac.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Fecha_Nac.Location = new System.Drawing.Point(217, 112);
            this.txt_Fecha_Nac.Name = "txt_Fecha_Nac";
            this.txt_Fecha_Nac.Size = new System.Drawing.Size(257, 21);
            this.txt_Fecha_Nac.TabIndex = 5;
            // 
            // txt_Telefono
            // 
            this.txt_Telefono.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Telefono.Location = new System.Drawing.Point(217, 141);
            this.txt_Telefono.Name = "txt_Telefono";
            this.txt_Telefono.Size = new System.Drawing.Size(257, 21);
            this.txt_Telefono.TabIndex = 6;
            // 
            // txt_ApellidoMat
            // 
            this.txt_ApellidoMat.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ApellidoMat.Location = new System.Drawing.Point(217, 83);
            this.txt_ApellidoMat.Name = "txt_ApellidoMat";
            this.txt_ApellidoMat.Size = new System.Drawing.Size(257, 21);
            this.txt_ApellidoMat.TabIndex = 7;
            // 
            // txt_ApellidoPat
            // 
            this.txt_ApellidoPat.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_ApellidoPat.Location = new System.Drawing.Point(217, 54);
            this.txt_ApellidoPat.Name = "txt_ApellidoPat";
            this.txt_ApellidoPat.Size = new System.Drawing.Size(257, 21);
            this.txt_ApellidoPat.TabIndex = 8;
            // 
            // txt_Nombre_Cliente
            // 
            this.txt_Nombre_Cliente.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Nombre_Cliente.Location = new System.Drawing.Point(217, 25);
            this.txt_Nombre_Cliente.Name = "txt_Nombre_Cliente";
            this.txt_Nombre_Cliente.Size = new System.Drawing.Size(257, 21);
            this.txt_Nombre_Cliente.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox1.Controls.Add(this.btn_Regresar);
            this.groupBox1.Controls.Add(this.btn_Eliminar_Cliente);
            this.groupBox1.Controls.Add(this.btn_Mostrar_Cliente);
            this.groupBox1.Controls.Add(this.btn_Modificar_Cliente);
            this.groupBox1.Controls.Add(this.btn_Agregar_Cliente);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Tai Le", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(493, 106);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(245, 181);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Opciones";
            // 
            // btn_Agregar_Cliente
            // 
            this.btn_Agregar_Cliente.BackColor = System.Drawing.Color.PaleGreen;
            this.btn_Agregar_Cliente.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Agregar_Cliente.Location = new System.Drawing.Point(6, 24);
            this.btn_Agregar_Cliente.Name = "btn_Agregar_Cliente";
            this.btn_Agregar_Cliente.Size = new System.Drawing.Size(233, 31);
            this.btn_Agregar_Cliente.TabIndex = 0;
            this.btn_Agregar_Cliente.Text = "AGREGAR";
            this.btn_Agregar_Cliente.UseVisualStyleBackColor = false;
            this.btn_Agregar_Cliente.Click += new System.EventHandler(this.btn_Agregar_Cliente_Click);
            // 
            // btn_Modificar_Cliente
            // 
            this.btn_Modificar_Cliente.BackColor = System.Drawing.Color.Aquamarine;
            this.btn_Modificar_Cliente.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Modificar_Cliente.Location = new System.Drawing.Point(6, 61);
            this.btn_Modificar_Cliente.Name = "btn_Modificar_Cliente";
            this.btn_Modificar_Cliente.Size = new System.Drawing.Size(233, 31);
            this.btn_Modificar_Cliente.TabIndex = 1;
            this.btn_Modificar_Cliente.Text = "MODIFICAR";
            this.btn_Modificar_Cliente.UseVisualStyleBackColor = false;
            this.btn_Modificar_Cliente.Click += new System.EventHandler(this.btn_Modificar_Cliente_Click);
            // 
            // btn_Mostrar_Cliente
            // 
            this.btn_Mostrar_Cliente.BackColor = System.Drawing.Color.Plum;
            this.btn_Mostrar_Cliente.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Mostrar_Cliente.Location = new System.Drawing.Point(6, 98);
            this.btn_Mostrar_Cliente.Name = "btn_Mostrar_Cliente";
            this.btn_Mostrar_Cliente.Size = new System.Drawing.Size(113, 31);
            this.btn_Mostrar_Cliente.TabIndex = 2;
            this.btn_Mostrar_Cliente.Text = "MOSTRAR";
            this.btn_Mostrar_Cliente.UseVisualStyleBackColor = false;
            this.btn_Mostrar_Cliente.Click += new System.EventHandler(this.btn_Mostrar_Cliente_Click);
            // 
            // btn_Eliminar_Cliente
            // 
            this.btn_Eliminar_Cliente.BackColor = System.Drawing.Color.Red;
            this.btn_Eliminar_Cliente.Font = new System.Drawing.Font("Microsoft Tai Le", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Eliminar_Cliente.Location = new System.Drawing.Point(125, 98);
            this.btn_Eliminar_Cliente.Name = "btn_Eliminar_Cliente";
            this.btn_Eliminar_Cliente.Size = new System.Drawing.Size(113, 31);
            this.btn_Eliminar_Cliente.TabIndex = 3;
            this.btn_Eliminar_Cliente.Text = "ELIMINAR";
            this.btn_Eliminar_Cliente.UseVisualStyleBackColor = false;
            this.btn_Eliminar_Cliente.Click += new System.EventHandler(this.btn_Eliminar_Cliente_Click);
            // 
            // btn_Regresar
            // 
            this.btn_Regresar.BackColor = System.Drawing.SystemColors.Info;
            this.btn_Regresar.Font = new System.Drawing.Font("Microsoft Tai Le", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Regresar.Location = new System.Drawing.Point(41, 135);
            this.btn_Regresar.Name = "btn_Regresar";
            this.btn_Regresar.Size = new System.Drawing.Size(161, 33);
            this.btn_Regresar.TabIndex = 24;
            this.btn_Regresar.Text = "Regresar";
            this.btn_Regresar.UseVisualStyleBackColor = false;
            this.btn_Regresar.Click += new System.EventHandler(this.btn_Regresar_Click);
            // 
            // dgv_Cliente
            // 
            this.dgv_Cliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Cliente.Location = new System.Drawing.Point(7, 294);
            this.dgv_Cliente.Name = "dgv_Cliente";
            this.dgv_Cliente.Size = new System.Drawing.Size(731, 194);
            this.dgv_Cliente.TabIndex = 11;
            // 
            // Form_Registro_Cliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ClientSize = new System.Drawing.Size(750, 500);
            this.Controls.Add(this.dgv_Cliente);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gb_Datos_Personales);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_Registro_Cliente";
            this.Text = "Form_Registro_Cliente";
            this.Load += new System.EventHandler(this.Form_Registro_Cliente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_Datos_Personales.ResumeLayout(false);
            this.gb_Datos_Personales.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Cliente)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lab_Cliente;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gb_Datos_Personales;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_Fecha_Nac;
        private System.Windows.Forms.TextBox txt_Nombre_Cliente;
        private System.Windows.Forms.TextBox txt_ApellidoPat;
        private System.Windows.Forms.TextBox txt_ApellidoMat;
        private System.Windows.Forms.TextBox txt_Telefono;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn_Agregar_Cliente;
        private System.Windows.Forms.Button btn_Eliminar_Cliente;
        private System.Windows.Forms.Button btn_Mostrar_Cliente;
        private System.Windows.Forms.Button btn_Modificar_Cliente;
        private System.Windows.Forms.Button btn_Regresar;
        private System.Windows.Forms.DataGridView dgv_Cliente;
    }
}