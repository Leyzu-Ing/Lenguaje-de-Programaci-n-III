﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad_3_CRUD.Formularios
{
    public partial class Form_Registro_Cliente : Form
    {
        public Form_Registro_Cliente()
        {
            InitializeComponent();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            this.Close();
            Form_Menú back = new Form_Menú();
            back.Show();
        }

        private void btn_Agregar_Cliente_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO Cliente (Nombre_Cliente, Apellido_Pat, Apellido_Mat, Fecha_Nacimiento, Telefono) VALUES ('" + txt_Nombre_Cliente.Text + "', '" + txt_ApellidoPat.Text + "', '" + txt_ApellidoMat.Text + "', '" + txt_Fecha_Nac.Text + "', '" + txt_Telefono.Text + "')", Conexion);
                cmd.CommandType = CommandType.Text;
                Conexion.Open();
                cmd.ExecuteNonQuery();

                txt_Nombre_Cliente.Clear();
                txt_ApellidoPat.Clear();
                txt_ApellidoMat.Clear();
                txt_Fecha_Nac.Clear();
                txt_Telefono.Clear();

                MessageBox.Show("El Cliente ha sido Agregado Correctamente. ");
            }
        }

        private void Form_Registro_Cliente_Load(object sender, EventArgs e)
        {

        }

        private void btn_Modificar_Cliente_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Cliente SET Apellido_Pat = '"+ txt_ApellidoPat.Text + "', Apellido_Mat = '"+ txt_ApellidoMat.Text + "', Fecha_Nacimiento = '"+ txt_Fecha_Nac.Text + "', Telefono = '"+ txt_Telefono.Text + "' Where Nombre_Cliente = '"+ txt_Nombre_Cliente.Text + "' ", Conexion);
                cmd.CommandType = CommandType.Text;
                Conexion.Open();
                cmd.ExecuteNonQuery();

                txt_Nombre_Cliente.Clear();
                txt_ApellidoPat.Clear();
                txt_ApellidoMat.Clear();
                txt_Fecha_Nac.Clear();
                txt_Telefono.Clear();

                MessageBox.Show("El Cliente ha sido Modificado Correctamente. ");
            }
        }

        private void btn_Eliminar_Cliente_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Cliente WHERE Nombre_Cliente = '"+ txt_Nombre_Cliente.Text + "'", Conexion);
                cmd.CommandType = CommandType.Text;
                Conexion.Open();
                cmd.ExecuteNonQuery();

                txt_Nombre_Cliente.Clear();
                txt_ApellidoPat.Clear();
                txt_ApellidoMat.Clear();
                txt_Fecha_Nac.Clear();
                txt_Telefono.Clear();

                MessageBox.Show("El Cliente ha sido Eliminado Correctamente. ");
            }
        }

        private void btn_Mostrar_Cliente_Click(object sender, EventArgs e)
        {
            DataTable DT = new DataTable();
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter Data = new SqlDataAdapter("Select * from Cliente", Conexion);
                Data.SelectCommand.CommandType = CommandType.Text; ;

                Conexion.Open();
                Data.Fill(DT);

                dgv_Cliente.DataSource = DT;
            }
        }
    }
}
