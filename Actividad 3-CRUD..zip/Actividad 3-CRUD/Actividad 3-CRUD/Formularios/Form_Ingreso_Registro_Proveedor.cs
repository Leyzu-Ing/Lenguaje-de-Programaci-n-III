﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD.Formularios
{
    public partial class Form_Ingreso_Registro_Proveedor : Form
    {
        public Form_Ingreso_Registro_Proveedor()
        {
            InitializeComponent();
        }

        private void btn_Entrar_Cliente_Click(object sender, EventArgs e)
        {
            if (txt_Contraseña_Proveedor.Text == "")
            {
                MessageBox.Show("Favor de Ingresar la Contraseña. ");
            }
            else if (txt_Contraseña_Proveedor.Text == "963852741")
            {
                Form_Registro_Proveedor form_Registro_Proveedor = new Form_Registro_Proveedor();
                form_Registro_Proveedor.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("La Contraseña es Incorrecta. ");
                txt_Contraseña_Proveedor.Clear();
            }
        }
    }
}
