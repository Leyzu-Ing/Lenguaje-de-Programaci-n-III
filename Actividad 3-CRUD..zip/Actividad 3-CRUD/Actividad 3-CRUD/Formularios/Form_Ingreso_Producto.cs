﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD.Formularios
{
    public partial class Form_Ingreso_Producto : Form
    {
        public Form_Ingreso_Producto()
        {
            InitializeComponent();
        }

        private void btn_Entrar_Cliente_Click(object sender, EventArgs e)
        {
            if (txt_Contraseña_Producto.Text == "")
            {
                MessageBox.Show("Favor de Ingresar la Contraseña. ");
            }
            else if (txt_Contraseña_Producto.Text == "963852741")
            {
                Form_Registro_Producto form_Registro_Producto = new Form_Registro_Producto();
                form_Registro_Producto.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("La Contraseña es Incorrecta. ");
                txt_Contraseña_Producto.Clear();
            }
        }
    }
}
