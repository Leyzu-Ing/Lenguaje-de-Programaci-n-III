﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Actividad_3_CRUD.Formularios
{
    public partial class Form_Registro_Proveedor : Form
    {
        public Form_Registro_Proveedor()
        {
            InitializeComponent();
        }

        private void btn_Regresar_Click(object sender, EventArgs e)
        {
            this.Close();       
            Form_Menú back = new Form_Menú();
            back.Show();
        }

        private void Form_Registro_Proveedor_Load(object sender, EventArgs e)
        {

        }

        private void btn_Agregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO Proveedor (Nombre, Dirección, Correo) VALUES ('"+ txt_Nombre_Proveedor.Text + "', '"+ txt_Dirección_Proveedor.Text + "', '"+ txt_Correo.Text + "')", Conexion);
                cmd.CommandType = CommandType.Text;
                Conexion.Open();
                cmd.ExecuteNonQuery();

                txt_Nombre_Proveedor.Clear();
                txt_Dirección_Proveedor.Clear();
                txt_Correo.Clear();

                MessageBox.Show("El Proveedor se ha Agregado correctamente");

            }

        }

        private void btn_Modificar_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("UPDATE Proveedor SET Dirección = '"+ txt_Dirección_Proveedor.Text + "', Correo = '"+ txt_Correo.Text + "' Where Nombre = '"+ txt_Nombre_Proveedor.Text + "' " , Conexion);
                cmd.CommandType = CommandType.Text; 
                Conexion.Open();
                cmd.ExecuteNonQuery();

                txt_Nombre_Proveedor.Clear();
                txt_Dirección_Proveedor.Clear();
                txt_Correo.Clear();

                MessageBox.Show("El Proveedor se ha Modificado Correctamente. ");

            }

        }

        private void btn_Eliminar_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM Proveedor Where Nombre = '"+txt_Nombre_Proveedor.Text + "'", Conexion);
                cmd.CommandType = CommandType.Text;
                Conexion.Open();
                cmd.ExecuteNonQuery();

                txt_Nombre_Proveedor.Clear();
                txt_Dirección_Proveedor.Clear();
                txt_Correo.Clear();

                MessageBox.Show("El Proveedor se ha Eliminado Correctamente. ");

            }
        }

        private void btn_Mostrar_Click(object sender, EventArgs e)
        {
            DataTable DT = new DataTable();
            using (SqlConnection Conexion = new SqlConnection("Data Source=ROG-ONE\\SQLEXPRESS;Initial Catalog=Zapateria_la_Esperanza;Integrated Security=True;Encrypt=False"))
            {
                SqlDataAdapter Data = new SqlDataAdapter("Select * from Proveedor", Conexion);
                Data.SelectCommand.CommandType = CommandType.Text; ;

                Conexion.Open();
                Data.Fill(DT);

                dgv_Proveedor.DataSource = DT;
            }
        }
    }
}
