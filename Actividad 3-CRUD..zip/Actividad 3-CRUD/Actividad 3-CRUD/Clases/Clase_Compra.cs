﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Actividad_3_CRUD.Clases
{
    public class Clase_Compra
    {
        public float Sumar ( float numero1, float numero2)
        {
            float resultado;
            resultado = numero1 + numero2;
            return resultado;
        }

        public float Restar ( float numero1, float numero2)
        {
            float resultado;
            resultado = numero1 - numero2;
            return resultado;
        }

        public float Multiplicar ( float numero1, float numero2)
        {
            float resultado;
            resultado = numero1 * numero2;
            return resultado;
        }

        public float Dividir ( float numero1, float numero2)
        {
            float resultado;
            resultado = numero1 / numero2;
            return resultado;   
        }
    }
}
