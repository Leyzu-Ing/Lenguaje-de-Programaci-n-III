﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Actividad_3_CRUD
{
    public partial class Form_Menú : Form
    {
        public Form_Menú()
        {
            InitializeComponent();
        }

        private void tool_Mensaje_Bienvenida_Click(object sender, EventArgs e)
        {
            Formularios.Form_Mensaje_de_Bienvenida mensaje_De_Bienvenida= new Formularios.Form_Mensaje_de_Bienvenida();
            mensaje_De_Bienvenida.Show();
            this.Hide();
        }

        private void salirToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tool_Quienes_Somos_Click(object sender, EventArgs e)
        {
            Formularios.Form_Quienes_Somos form_Quienes_Somos = new Formularios.Form_Quienes_Somos();
            form_Quienes_Somos.Show();
            this.Hide();
        }

        private void Tool_Misión_Click(object sender, EventArgs e)
        {
            Formularios.Form_Mision form_Mision = new Formularios.Form_Mision();
            form_Mision.Show();
            this.Hide();
        }

        private void Tool_Vision_Click(object sender, EventArgs e)
        {
            Formularios.Form_Vision form_Vision = new Formularios.Form_Vision();
            form_Vision.Show();
            this.Hide();
        }

        private void Tool_Damas_Click(object sender, EventArgs e)
        {
            Formularios.Form_Damas form_Damas = new Formularios.Form_Damas();
            form_Damas.Show();
            this.Hide();
        }

        private void caballerosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formularios.Form_Caballeros form_Caballeros = new Formularios.Form_Caballeros();
            form_Caballeros.Show();
            this.Hide();
        }

        private void Tool_Cliente_Click(object sender, EventArgs e)
        {
            Formularios.Form_Ingreso_Cliente form_Ingreso_Cliente = new Formularios.Form_Ingreso_Cliente();
            form_Ingreso_Cliente.Show();
            this.Hide();
        }

        private void Tool_Proveedor_Click(object sender, EventArgs e)
        {
            Formularios.Form_Ingreso_Registro_Proveedor form_Ingreso_Registro_ = new Formularios.Form_Ingreso_Registro_Proveedor();
            form_Ingreso_Registro_.Show();
            this.Hide();
        }

        private void Tool_Producto_Click(object sender, EventArgs e)
        {
            Formularios.Form_Ingreso_Producto form_Ingreso_Producto = new Formularios.Form_Ingreso_Producto();
            form_Ingreso_Producto.Show();
            this.Hide();
        }

        private void Tool_Compras_Click(object sender, EventArgs e)
        {
            Formularios.Form_Compra form_Compra = new Formularios.Form_Compra();
            form_Compra.Show();
            this.Hide();
        }
    }
}
